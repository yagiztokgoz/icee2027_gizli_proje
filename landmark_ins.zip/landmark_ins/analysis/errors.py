"""Navigation error metrics (estimated minus true). Definitions: docs/CONVENTIONS.md.

horizontal_m : ground distance between estimated and true position,
               sqrt(dNorth^2 + dEast^2), with dNorth/dEast the curvilinear
               (latitude/longitude) differences converted to metres.
height_m     : estimated ellipsoidal height minus true ellipsoidal height
               (positive = the INS believes it is higher than it is).
Neither is an ECEF x/y/z quantity.
"""
import numpy as np
from scipy.spatial.transform import Rotation

from nav.frames import (curvature_radii, dcm_ecef_to_ned_array,
                        ecef_to_geodetic_array, wrap_pi)


def navigation_errors(truth, r_hat, v_hat, C_hat):
    """Return a dict of error histories (all length N).

    position_ned_m   (N,3)  [dNorth, dEast, dDown = -height error]
    velocity_ned_mps (N,3)  ECEF-velocity error rotated into NED at the true position
    attitude_ned_rad (N,3)  attitude error vector about N, E, D axes (see conventions)
    horizontal_m     (N,)   sqrt(dNorth^2 + dEast^2)
    height_m         (N,)   estimated minus true ellipsoidal height
    """
    lla_hat = ecef_to_geodetic_array(r_hat)
    lat, lon, h = truth.lla[:, 0], truth.lla[:, 1], truth.lla[:, 2]
    M, N = curvature_radii(lat)
    north = (lla_hat[:, 0] - lat) * (M + h)
    east = wrap_pi(lla_hat[:, 1] - lon) * (N + h) * np.cos(lat)
    height = lla_hat[:, 2] - h

    C_en = dcm_ecef_to_ned_array(lat, lon)
    vel = np.einsum("kij,kj->ki", C_en, v_hat - truth.v_e)
    eps_e = Rotation.from_matrix(C_hat @ truth.C_be.transpose(0, 2, 1)).as_rotvec()
    att = np.einsum("kij,kj->ki", C_en, eps_e)

    return {"position_ned_m": np.column_stack([north, east, -height]),
            "velocity_ned_mps": vel,
            "attitude_ned_rad": att,
            "horizontal_m": np.hypot(north, east),
            "height_m": height}
