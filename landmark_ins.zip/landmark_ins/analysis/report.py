"""Text report: error table and landmark visibility / feasibility check."""
import numpy as np

from nav.constants import DEG
from nav.frames import curvature_radii, geodetic_to_ecef, wrap_pi


def true_runs(mask):
    """Inclusive (start, end) index pairs of consecutive True values in a boolean array."""
    padded = np.concatenate(([0], np.asarray(mask, dtype=int), [0]))
    edges = np.flatnonzero(np.diff(padded))
    return [(int(a), int(b) - 1) for a, b in zip(edges[0::2], edges[1::2])]


def landmark_geometry(result):
    """Per landmark: closest approach and camera visibility windows (truth geometry)."""
    truth, cam = result.truth, result.camera
    out = []
    for lm in result.cfg["landmarks"]:
        lm_e = geodetic_to_ecef(lm["lat_deg"] * DEG, lm["lon_deg"] * DEG, lm["alt_m"])
        k_ca = int(np.argmin(np.linalg.norm(truth.r_e - lm_e, axis=1)))
        d_c, rng = cam.landmark_in_camera(truth.r_e, truth.C_be, lm_e)
        windows = true_runs(cam.is_visible(d_c, rng))
        lat, lon, h = truth.lla[k_ca]
        M, N = curvature_radii(np.array([lat]))
        d_north = (lm["lat_deg"] * DEG - lat) * (M[0] + h)
        d_east = float(wrap_pi(lm["lon_deg"] * DEG - lon)) * (N[0] + h) * np.cos(lat)
        out.append({"id": lm["id"], "lm_e": lm_e, "k_closest": k_ca,
                    "closest_m": float(np.linalg.norm(truth.r_e[k_ca] - lm_e)),
                    "miss_horizontal_m": float(np.hypot(d_north, d_east)),
                    "windows": windows, "d_c_true": d_c, "range_true": rng})
    return out


def _los_discrepancy_deg(result, case, geo, k):
    """Angle between the true and the INS-predicted line of sight to a landmark, and
    whether the INS-predicted landmark falls inside the field of view."""
    cam = result.camera
    d_true = geo["d_c_true"][k]
    d_pred, rng_pred = cam.landmark_in_camera(case.r[k], case.C[k], geo["lm_e"])
    cosang = np.dot(d_true, d_pred) / (np.linalg.norm(d_true) * np.linalg.norm(d_pred))
    return (float(np.degrees(np.arccos(np.clip(cosang, -1.0, 1.0)))),
            bool(cam.is_visible(d_pred, rng_pred)))


def build_report(result):
    cfg, truth = result.cfg, result.truth
    t = truth.t
    sc = cfg.get("scenario", {})
    L = []
    L.append("=" * 78)
    L.append(f"SCENARIO: {sc.get('name', '(unnamed)')}")
    L.append("=" * 78)
    dist_km = np.sum(np.linalg.norm(np.diff(truth.r_e, axis=0), axis=1)) / 1000.0
    h = truth.lla[:, 2]
    L.append(f"Route: {t[-1] / 60:.1f} min, {dist_km:.1f} km, speed {cfg['route']['speed_mps']:.0f} m/s, "
             f"height {h.min():.0f}..{h.max():.0f} m, completed={truth.completed}")
    L.append(f"Seed: {result.seed}.  Error-free IMU check: max position error "
             f"{result.ideal_check_max_error_m:.1e} m")
    L.append("")
    L.append("Definitions: horizontal = sqrt(dNorth^2 + dEast^2) ground distance;")
    L.append("             height     = INS ellipsoidal height - true height (+ = INS too high).")
    L.append("")

    # ---- error table -------------------------------------------------------
    step = 600.0
    marks = [int(s / truth.dt) for s in np.arange(0.0, t[-1], step)] + [len(t) - 1]
    head = f"{'t [min]':>8}" + "".join(f" | {c.name[:24]:^24}" for c in result.cases.values())
    sub = f"{'':>8}" + "".join(f" | {'horiz [m]':>11} {'height [m]':>12}" for _ in result.cases)
    L += ["INS error growth (no landmarks used):", head, sub]
    for k in marks:
        row = f"{t[k] / 60:8.1f}"
        for c in result.cases.values():
            row += f" | {c.errors['horizontal_m'][k]:11.1f} {c.errors['height_m'][k]:12.1f}"
        L.append(row)
    L.append("")

    # ---- landmark feasibility ---------------------------------------------
    c = cfg["camera"]
    L.append(f"Landmark visibility (camera pitched {c['mounting_rpy_deg'][1]:+.0f} deg, "
             f"FOV {c['fov_horizontal_deg']:.0f}x{c['fov_vertical_deg']:.0f} deg, "
             f"max range {c['max_range_m'] / 1000:.0f} km; truth geometry, no noise):")
    L.append(f"{'id':>5} {'t_pass[min]':>11} {'miss, horiz [m]':>16} {'visible from-to [s]':>20} "
             f"{'dur [s]':>8} {'range start/end [km]':>22}")
    geos = landmark_geometry(result)
    problems = []
    for g in geos:
        base = f"{g['id']:>5} {t[g['k_closest']] / 60:11.1f} {g['miss_horizontal_m']:16.0f}"
        if not g["windows"]:
            L.append(base + f" {'NEVER VISIBLE':>20}")
            problems.append(g["id"])
            continue
        k0, k1 = g["windows"][0]
        extra = f" (+{len(g['windows']) - 1} more)" if len(g["windows"]) > 1 else ""
        L.append(base + f" {t[k0]:9.0f} -{t[k1]:<9.0f} {t[k1] - t[k0]:8.0f} "
                 f"{g['range_true'][k0] / 1000:10.1f} /{g['range_true'][k1] / 1000:5.1f}{extra}")
    L.append("")

    base_case = result.cases.get("baro_damped", result.cases["unaided"])
    L.append(f"INS error at the moment each landmark first becomes visible ({base_case.name}, "
             "no landmark fixes used):")
    L.append(f"{'id':>5} {'horiz err [m]':>14} {'height err [m]':>15} {'LOS error [deg]':>16} "
             f"{'predicted in FOV':>17}")
    for g in geos:
        if not g["windows"]:
            continue
        k0 = g["windows"][0][0]
        ang, in_fov = _los_discrepancy_deg(result, base_case, g, k0)
        L.append(f"{g['id']:>5} {base_case.errors['horizontal_m'][k0]:14.0f} "
                 f"{base_case.errors['height_m'][k0]:15.1f} {ang:16.2f} "
                 f"{'yes' if in_fov else 'no':>17}")
    L.append("(LOS error = angle between the true and the INS-predicted direction to the landmark.")
    L.append(" Rows after the first are what the INS alone would see; with landmark fixes the")
    L.append(" error is reset at every pass, so only the growth between landmarks matters.)")
    L.append("")
    if problems:
        L.append(f"!! NOT VISIBLE with the current route/camera: {', '.join(problems)}")
    else:
        L.append("OK: every landmark is seen by the camera at least once on this route.")
    return "\n".join(L)
