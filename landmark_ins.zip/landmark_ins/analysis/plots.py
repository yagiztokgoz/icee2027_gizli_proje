"""Figures (PNG). Error axes are labelled with their exact meaning."""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from nav.constants import DEG
from nav.frames import curvature_radii, wrap_pi

COLORS = {"unaided": "#c0392b", "baro_damped": "#1f77b4"}


def _offsets_km(lla, lla_ref):
    """North/east offsets [km] of lla (N,3 or 3,) from lla_ref (3,), curvilinear."""
    lla = np.atleast_2d(lla)
    M, N = curvature_radii(np.array([lla_ref[0]]))
    north = (lla[:, 0] - lla_ref[0]) * (M[0] + lla_ref[2])
    east = wrap_pi(lla[:, 1] - lla_ref[1]) * (N[0] + lla_ref[2]) * np.cos(lla_ref[0])
    return north / 1000.0, east / 1000.0


def plot_ground_track(truth, cases, landmarks, path, decimate=100):
    ref = truth.lla[0]
    fig, ax = plt.subplots(figsize=(8, 8))
    n_t, e_t = _offsets_km(truth.lla, ref)
    ax.plot(e_t, n_t, "k-", lw=2.0, label="true route")
    for key, case in cases.items():
        n_i, e_i = _offsets_km(case.lla[::decimate], ref)
        ax.plot(e_i, n_i, "--", lw=1.2, color=COLORS.get(key), label=f"{case.name}")
        ax.plot(e_i[-1], n_i[-1], "x", color=COLORS.get(key), ms=9)
    for lm in landmarks:
        lla = np.array([lm["lat_deg"] * DEG, lm["lon_deg"] * DEG, lm["alt_m"]])
        n_l, e_l = _offsets_km(lla, ref)
        is_x = lm["id"] == "X"
        ax.plot(e_l, n_l, "*" if is_x else "^", color="darkgreen" if is_x else "tab:orange",
                ms=15 if is_x else 9, zorder=5)
        ax.annotate(lm["id"] + (" (rescue area)" if is_x else ""), (e_l[0], n_l[0]),
                    textcoords="offset points", xytext=(7, 6), fontsize=9)
    ax.plot(e_t[0], n_t[0], "go", ms=9, label="start")
    ax.plot(e_t[-1], n_t[-1], "ks", ms=8, label="true end of route")
    ax.set_xlabel("East of start [km]")
    ax.set_ylabel("North of start [km]")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.4)
    ax.legend(loc="best", fontsize=9)
    ax.set_title("Ground track: true route vs INS-computed position (x = end of flight)")
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)


def plot_error_overview(truth, cases, landmark_times_s, path):
    t = truth.t / 60.0
    fig, axes = plt.subplots(3, 1, figsize=(10, 10), sharex=True)
    for key, case in cases.items():
        c = COLORS.get(key)
        axes[0].plot(t, case.errors["horizontal_m"] / 1000.0, color=c, label=case.name)
        axes[1].plot(t, case.errors["height_m"], color=c, label=case.name)
    axes[0].set_ylabel("Horizontal position error [km]\n= ground distance INS-to-truth")
    axes[1].set_ylabel("Height error [m]  (+ = INS too high)\nsymmetric-log scale")
    axes[1].set_yscale("symlog", linthresh=10.0)
    if "baro_damped" in cases:
        axes[2].plot(t, cases["baro_damped"].errors["height_m"], color=COLORS["baro_damped"])
        axes[2].axhline(0.0, color="k", lw=0.6)
        axes[2].set_ylabel("Height error, baro-damped\n[m] (linear zoom)")
    else:
        axes[2].set_visible(False)
    for name, tl in landmark_times_s.items():
        for ax in axes:
            ax.axvline(tl / 60.0, color="gray", ls=":", lw=0.9)
        axes[0].annotate(name, (tl / 60.0, 1.0), xycoords=("data", "axes fraction"),
                         rotation=90, ha="right", va="top", fontsize=8, color="gray")
    for ax in axes:
        ax.grid(True, alpha=0.4)
    axes[0].legend(loc="center left")
    axes[-1].set_xlabel("Time [min]   (dotted lines: closest approach to each landmark)")
    axes[0].set_title("INS error growth with no landmark fixes")
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)


def plot_error_components(truth, case, path):
    t = truth.t / 60.0
    e = case.errors
    fig, axes = plt.subplots(3, 1, figsize=(10, 9), sharex=True)
    pos = e["position_ned_m"]
    axes[0].plot(t, pos[:, 0], label="North")
    axes[0].plot(t, pos[:, 1], label="East")
    axes[0].plot(t, -pos[:, 2], label="Height (up)")
    axes[0].set_ylabel("Position error [m]")
    for i, lab in enumerate(["North", "East", "Down"]):
        axes[1].plot(t, e["velocity_ned_mps"][:, i], label=lab)
    axes[1].set_ylabel("Velocity error [m/s]")
    for i, lab in enumerate(["tilt about N", "tilt about E", "heading (about D)"]):
        axes[2].plot(t, e["attitude_ned_rad"][:, i] / DEG, label=lab)
    axes[2].set_ylabel("Attitude error [deg]")
    axes[2].set_xlabel("Time [min]")
    for ax in axes:
        ax.grid(True, alpha=0.4)
        ax.legend(loc="upper left", fontsize=8)
    axes[0].set_title(f"Error components, {case.name}")
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
