"""Random process helpers."""
import math

import numpy as np
from scipy.signal import lfilter


def gauss_markov(n, sigma, tau, dt, rng, dim=3):
    """First-order Gauss-Markov sequence, shape (n, dim).

    Stationary standard deviation `sigma`, correlation time `tau`, step `dt`.
    The first sample is drawn from the stationary distribution.
    """
    if sigma <= 0.0:
        return np.zeros((n, dim))
    a = math.exp(-dt / tau)
    w = rng.normal(0.0, sigma * math.sqrt(1.0 - a * a), (n, dim))
    w[0] = rng.normal(0.0, sigma, dim)
    return lfilter([1.0], [1.0, -a], w, axis=0)
