"""Camera geometry (fixed, body-mounted pinhole camera). No noise, no filter.

Camera frame c: x right, y down, z along the optical axis.
Mounting: `mounting_rpy_deg` rotates a boresight-aligned FRD frame relative to the
body (pitch negative = looking down, positive yaw = looking right).
Measurement angles:  az = atan2(x, z) (positive right),  el = atan2(-y, hypot(x, z)) (positive up).
"""
import math

import numpy as np

from .constants import DEG
from .frames import euler_to_dcm

# boresight-aligned FRD (forward, right, down) -> camera (right, down, forward)
_FRD_TO_CAMERA = np.array([[0.0, 1.0, 0.0],
                           [0.0, 0.0, 1.0],
                           [1.0, 0.0, 0.0]])


class CameraModel:
    def __init__(self, cam_cfg):
        roll, pitch, yaw = (a * DEG for a in cam_cfg["mounting_rpy_deg"])
        R = euler_to_dcm(roll, pitch, yaw)               # boresight-aligned FRD -> body
        self.C_bc = _FRD_TO_CAMERA @ R.T                 # body -> camera
        self.lever_arm_b = np.asarray(cam_cfg["lever_arm_m"], dtype=float)
        self.tan_half_h = math.tan(0.5 * cam_cfg["fov_horizontal_deg"] * DEG)
        self.tan_half_v = math.tan(0.5 * cam_cfg["fov_vertical_deg"] * DEG)
        self.max_range_m = float(cam_cfg["max_range_m"])

    def landmark_in_camera(self, r_e, C_be, landmark_e):
        """Vector from the camera to the landmark, expressed in the camera frame.

        r_e: (..., 3) vehicle position, C_be: (..., 3, 3), landmark_e: (3,).
        Returns (d_c (..., 3), range (...,)).
        """
        r_cam = r_e + np.einsum("...ij,j->...i", C_be, self.lever_arm_b)
        d_e = landmark_e - r_cam
        d_b = np.einsum("...ji,...j->...i", C_be, d_e)    # C_be^T @ d_e
        return d_b @ self.C_bc.T, np.linalg.norm(d_e, axis=-1)

    def is_visible(self, d_c, rng):
        """Pinhole field-of-view and maximum-range test."""
        x, y, z = d_c[..., 0], d_c[..., 1], d_c[..., 2]
        return ((z > 0.0) & (np.abs(x) <= self.tan_half_h * z)
                & (np.abs(y) <= self.tan_half_v * z) & (rng <= self.max_range_m))

    @staticmethod
    def az_el(d_c):
        """(azimuth, elevation) in radians."""
        x, y, z = d_c[..., 0], d_c[..., 1], d_c[..., 2]
        return np.arctan2(x, z), np.arctan2(-y, np.hypot(x, z))
