"""Scenario configuration loader and validator."""
from pathlib import Path

import yaml

DEFAULT_CONFIG = Path(__file__).resolve().parent.parent / "config" / "scenario.yaml"


class ConfigError(ValueError):
    """Raised when the scenario file is missing an entry or holds an invalid value."""


def load_config(path=None):
    """Load and validate the scenario YAML file; returns a nested dict."""
    path = Path(path) if path is not None else DEFAULT_CONFIG
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    validate_config(cfg)
    return cfg


def _get(cfg, dotted):
    node = cfg
    for key in dotted.split("."):
        if not isinstance(node, dict) or key not in node:
            raise ConfigError(f"missing required entry '{dotted}'")
        node = node[key]
    return node


def _num(cfg, dotted, lo=None, hi=None, lo_open=False):
    v = _get(cfg, dotted)
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        raise ConfigError(f"'{dotted}' must be a number, got {v!r}")
    if lo is not None and (v <= lo if lo_open else v < lo):
        op = ">" if lo_open else ">="
        raise ConfigError(f"'{dotted}' must be {op} {lo}, got {v}")
    if hi is not None and v > hi:
        raise ConfigError(f"'{dotted}' must be <= {hi}, got {v}")
    return float(v)


def _vec3(node, name, nonneg=False):
    if (not isinstance(node, (list, tuple)) or len(node) != 3
            or any(isinstance(x, bool) or not isinstance(x, (int, float)) for x in node)):
        raise ConfigError(f"'{name}' must be a list of 3 numbers, got {node!r}")
    if nonneg and any(x < 0 for x in node):
        raise ConfigError(f"'{name}' must be non-negative, got {node!r}")


def _lat_lon(lat, lon, name):
    if not -90.0 <= lat <= 90.0:
        raise ConfigError(f"{name}: latitude {lat} outside [-90, 90]")
    if not -180.0 <= lon <= 180.0:
        raise ConfigError(f"{name}: longitude {lon} outside [-180, 180]")


def validate_config(cfg):
    """Raise ConfigError with a precise message if the scenario is unusable."""
    if not isinstance(cfg, dict):
        raise ConfigError("scenario file is empty or not a YAML mapping")

    # simulation
    imu_rate = _num(cfg, "simulation.imu_rate_hz", 0.0, lo_open=True)
    _num(cfg, "simulation.max_duration_s", 0.0, lo_open=True)
    _get(cfg, "simulation.seed")

    # route
    _lat_lon(_num(cfg, "route.start.lat_deg"), _num(cfg, "route.start.lon_deg"), "route.start")
    _num(cfg, "route.start.alt_m")
    wps = _get(cfg, "route.waypoints")
    if not isinstance(wps, list) or not wps:
        raise ConfigError("'route.waypoints' must be a non-empty list")
    for i, w in enumerate(wps):
        _vec3(w, f"route.waypoints[{i}]")
        _lat_lon(w[0], w[1], f"route.waypoints[{i}]")
    _num(cfg, "route.speed_mps", 0.0, lo_open=True)
    _num(cfg, "route.acceptance_radius_m", 0.0, lo_open=True)
    _num(cfg, "route.heading_gain_per_s", 0.0, lo_open=True)
    _num(cfg, "route.max_bank_deg", 0.0, 60.0, lo_open=True)
    _num(cfg, "route.max_roll_rate_dps", 0.0, lo_open=True)
    _num(cfg, "route.roll_time_constant_s", 0.0, lo_open=True)
    _num(cfg, "route.altitude_gain_per_s", 0.0, lo_open=True)
    _num(cfg, "route.max_flight_path_angle_deg", 0.0, 30.0, lo_open=True)
    _num(cfg, "route.max_flight_path_rate_dps", 0.0, lo_open=True)
    _num(cfg, "route.flight_path_time_constant_s", 0.0, lo_open=True)

    # landmarks
    lms = _get(cfg, "landmarks")
    if not isinstance(lms, list):
        raise ConfigError("'landmarks' must be a list")
    seen = set()
    for i, lm in enumerate(lms):
        for key in ("id", "lat_deg", "lon_deg", "alt_m", "sigma_ned_m"):
            if key not in lm:
                raise ConfigError(f"landmarks[{i}] is missing '{key}'")
        if lm["id"] in seen:
            raise ConfigError(f"duplicate landmark id '{lm['id']}'")
        seen.add(lm["id"])
        _lat_lon(lm["lat_deg"], lm["lon_deg"], f"landmark '{lm['id']}'")
        _vec3(lm["sigma_ned_m"], f"landmarks[{i}].sigma_ned_m", nonneg=True)

    # initial errors
    for key in ("position_ned_m", "velocity_ned_mps", "attitude_ned_deg"):
        _vec3(_get(cfg, f"initial_errors.{key}"), f"initial_errors.{key}", nonneg=True)

    # IMU
    for sensor, keys in (("gyro", ("bias_sigma_dph", "bias_instability_dph", "arw_dpsh",
                                   "scale_factor_ppm", "misalignment_mrad")),
                         ("accel", ("bias_sigma_mg", "bias_instability_mg", "vrw_mpsph",
                                    "scale_factor_ppm", "misalignment_mrad"))):
        for key in keys:
            _num(cfg, f"imu.{sensor}.{key}", 0.0)
        _num(cfg, f"imu.{sensor}.bias_corr_time_s", 0.0, lo_open=True)

    # barometer
    enabled = _get(cfg, "baro.enabled")
    if not isinstance(enabled, bool):
        raise ConfigError("'baro.enabled' must be true or false")
    if enabled:
        rate = _num(cfg, "baro.rate_hz", 0.0, lo_open=True)
        ratio = imu_rate / rate
        if ratio < 1.0 or abs(ratio - round(ratio)) > 1e-9:
            raise ConfigError("'simulation.imu_rate_hz' must be an integer multiple of "
                              f"'baro.rate_hz' (got {imu_rate} / {rate})")
        _num(cfg, "baro.noise_m", 0.0)
        _num(cfg, "baro.bias_sigma_m", 0.0)
        _num(cfg, "baro.bias_corr_time_s", 0.0, lo_open=True)
        _num(cfg, "baro.vertical_damping_time_constant_s", 0.0, lo_open=True)

    # camera
    _vec3(_get(cfg, "camera.mounting_rpy_deg"), "camera.mounting_rpy_deg")
    _vec3(_get(cfg, "camera.lever_arm_m"), "camera.lever_arm_m")
    _num(cfg, "camera.fov_horizontal_deg", 0.0, 170.0, lo_open=True)
    _num(cfg, "camera.fov_vertical_deg", 0.0, 170.0, lo_open=True)
    _num(cfg, "camera.max_range_m", 0.0, lo_open=True)
    _num(cfg, "camera.frame_rate_hz", 0.0, lo_open=True)
    _num(cfg, "camera.angle_noise_mrad", 0.0)
    _num(cfg, "camera.boresight_error_mrad", 0.0)
    _num(cfg, "camera.trigger_distance_m", 0.0, lo_open=True)
