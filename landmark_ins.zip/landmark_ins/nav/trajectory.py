"""Truth trajectory generator (kinematic coordinated-turn model, ECEF).

The aircraft flies at constant speed through the waypoint list. Heading is
steered toward the active waypoint with a bank-limited coordinated turn;
height is held / changed with a rate-limited flight path angle. Position is
integrated in ECEF with a trapezoidal rule.

Modeling assumption (see docs/CONVENTIONS.md): the truth path does NOT depend on
the navigation error, i.e. the route is flown exactly while the INS error
accumulates in the background.
"""
import math
from dataclasses import dataclass

import numpy as np

from .constants import DEG, G0
from .frames import (dcm_ecef_to_ned, dcm_ned_to_ecef, ecef_to_geodetic,
                     euler_to_dcm, geodetic_to_ecef, wrap_pi)


@dataclass
class TruthTrajectory:
    t: np.ndarray            # (N,)      time [s]
    r_e: np.ndarray          # (N, 3)    ECEF position [m]
    v_e: np.ndarray          # (N, 3)    ECEF velocity [m/s]
    C_be: np.ndarray         # (N, 3, 3) body -> ECEF
    lla: np.ndarray          # (N, 3)    lat [rad], lon [rad], ellipsoidal height [m]
    euler: np.ndarray        # (N, 3)    roll, pitch, yaw [rad] w.r.t. NED
    wp_index: np.ndarray     # (N,)      active waypoint index
    dt: float
    completed: bool = False  # True if the last waypoint was reached

    def __len__(self):
        return len(self.t)


def _clip(x, lo, hi):
    return lo if x < lo else hi if x > hi else x


def _ned_velocity(speed, course, gamma):
    cg = math.cos(gamma)
    return np.array([speed * cg * math.cos(course),
                     speed * cg * math.sin(course),
                     -speed * math.sin(gamma)])


def generate_truth(cfg):
    """Generate the truth trajectory from the scenario config dict."""
    sim, rc = cfg["simulation"], cfg["route"]
    dt = 1.0 / sim["imu_rate_hz"]
    n_max = int(sim["max_duration_s"] / dt) + 1

    speed = rc["speed_mps"]
    accept = rc["acceptance_radius_m"]
    k_heading = rc["heading_gain_per_s"]
    bank_max = rc["max_bank_deg"] * DEG
    roll_rate_max = rc["max_roll_rate_dps"] * DEG
    tau_roll = rc["roll_time_constant_s"]
    k_alt = rc["altitude_gain_per_s"]
    gamma_max = rc["max_flight_path_angle_deg"] * DEG
    gamma_rate_max = rc["max_flight_path_rate_dps"] * DEG
    tau_gamma = rc["flight_path_time_constant_s"]

    wps = [(w[0] * DEG, w[1] * DEG, float(w[2])) for w in rc["waypoints"]]
    wps_e = [geodetic_to_ecef(*w) for w in wps]

    s = rc["start"]
    lat, lon, h = s["lat_deg"] * DEG, s["lon_deg"] * DEG, float(s["alt_m"])
    r = geodetic_to_ecef(lat, lon, h)

    if rc.get("initial_heading_deg") is None:
        d_n = dcm_ecef_to_ned(lat, lon) @ (wps_e[0] - r)
        course = math.atan2(d_n[1], d_n[0])
    else:
        course = rc["initial_heading_deg"] * DEG
    bank, gamma = 0.0, 0.0
    v = dcm_ned_to_ecef(lat, lon) @ _ned_velocity(speed, course, gamma)

    t_arr = np.empty(n_max)
    r_arr = np.empty((n_max, 3))
    v_arr = np.empty((n_max, 3))
    C_arr = np.empty((n_max, 3, 3))
    lla_arr = np.empty((n_max, 3))
    eul_arr = np.empty((n_max, 3))
    wp_arr = np.empty(n_max, dtype=int)

    def store(k, wp):
        t_arr[k] = k * dt
        r_arr[k] = r
        v_arr[k] = v
        C_arr[k] = dcm_ned_to_ecef(lat, lon) @ euler_to_dcm(bank, gamma, course)
        lla_arr[k] = (lat, lon, h)
        eul_arr[k] = (bank, gamma, wrap_pi(course))
        wp_arr[k] = wp

    wp = 0
    completed = False
    store(0, wp)
    k = 0
    while k < n_max - 1:
        # --- guidance --------------------------------------------------------
        d_n = dcm_ecef_to_ned(lat, lon) @ (wps_e[wp] - r)
        if math.hypot(d_n[0], d_n[1]) < accept:
            wp += 1
            if wp == len(wps):
                wp -= 1
                completed = True
                break
            d_n = dcm_ecef_to_ned(lat, lon) @ (wps_e[wp] - r)

        bearing = math.atan2(d_n[1], d_n[0])
        course_rate_cmd = k_heading * float(wrap_pi(bearing - course))
        bank_cmd = _clip(math.atan(speed * course_rate_cmd / G0), -bank_max, bank_max)
        bank += _clip((bank_cmd - bank) / tau_roll, -roll_rate_max, roll_rate_max) * dt
        course += G0 * math.tan(bank) / speed * dt

        gamma_cmd = _clip(k_alt * (wps[wp][2] - h) / speed, -gamma_max, gamma_max)
        gamma += _clip((gamma_cmd - gamma) / tau_gamma, -gamma_rate_max, gamma_rate_max) * dt

        # --- kinematics (ECEF, trapezoidal position update) ------------------
        lat_p, lon_p, _ = ecef_to_geodetic(r + v * dt)
        v_next = dcm_ned_to_ecef(lat_p, lon_p) @ _ned_velocity(speed, course, gamma)
        r = r + 0.5 * (v + v_next) * dt
        v = v_next
        lat, lon, h = ecef_to_geodetic(r)

        k += 1
        store(k, wp)

    n = k + 1
    return TruthTrajectory(t=t_arr[:n], r_e=r_arr[:n], v_e=v_arr[:n], C_be=C_arr[:n],
                           lla=lla_arr[:n], euler=eul_arr[:n], wp_index=wp_arr[:n],
                           dt=dt, completed=completed)
