"""IMU simulation.

ideal_imu():     exact inverse of the INS mechanization -> error-free increments.
ImuErrorModel:   adds tactical-grade errors to those increments.

Error model per sensor (gyro and accelerometer, 3 axes each):
    measured = M @ ideal + bias + noise
    M        = I + diag(scale factor) + off-diagonal misalignment   (constant per run)
    bias     = turn-on bias (constant per run, sigma = bias_sigma)
               + first-order Gauss-Markov "bias instability" (stationary sigma =
               bias_instability, correlation time bias_corr_time)
    noise    = white; angle/velocity increments have std = ARW*sqrt(dt) / VRW*sqrt(dt)
"""
import math

import numpy as np
from scipy.spatial.transform import Rotation

from .constants import DPH, DPSH, MG, MPSPH, MRAD, OMEGA_IE_VEC, PPM
from .earth import coriolis_term_array, gravity_ecef_array
from .frames import rotvec_to_dcm
from .noise import gauss_markov


def ideal_imu(truth):
    """Error-free (dtheta, dv) increments, each (N-1, 3), body frame.

    These are the exact inverse of `nav.ins.StrapdownEcef.step`, so an INS fed
    with them reproduces the truth to floating-point precision.
    """
    dt = truth.dt
    E = rotvec_to_dcm(OMEGA_IE_VEC * dt)               # exp(+[w_ie x] dt)
    E_half = rotvec_to_dcm(-OMEGA_IE_VEC * dt / 2.0)   # exp(-[w_ie x] dt/2)
    C0, C1 = truth.C_be[:-1], truth.C_be[1:]

    dtheta = Rotation.from_matrix(C0.transpose(0, 2, 1) @ E @ C1).as_rotvec()
    C_mid = E_half @ C0 @ Rotation.from_rotvec(0.5 * dtheta).as_matrix()

    r_mid = truth.r_e[:-1] + 0.5 * truth.v_e[:-1] * dt
    a = (truth.v_e[1:] - truth.v_e[:-1]
         - (gravity_ecef_array(r_mid) - coriolis_term_array(truth.v_e[:-1])) * dt)
    dv = np.einsum("kji,kj->ki", C_mid, a)             # C_mid^T @ a
    return dtheta, dv


def _sensor_matrix(sf_sigma, mis_sigma, rng):
    """I + scale-factor errors (diagonal) + misalignments (off-diagonal)."""
    M = np.eye(3) + np.diag(rng.normal(0.0, sf_sigma, 3))
    off = rng.normal(0.0, mis_sigma, (3, 3))
    np.fill_diagonal(off, 0.0)
    return M + off


class ImuErrorModel:
    """One random realization of IMU errors (fixed per run)."""

    def __init__(self, imu_cfg, dt, rng):
        g, a = imu_cfg["gyro"], imu_cfg["accel"]
        self.dt = dt
        self.rng = rng

        self.gyro_bias_const = rng.normal(0.0, g["bias_sigma_dph"] * DPH, 3)
        self.gyro_bi_sigma = g["bias_instability_dph"] * DPH
        self.gyro_bi_tau = g["bias_corr_time_s"]
        self.gyro_arw = g["arw_dpsh"] * DPSH
        self.gyro_M = _sensor_matrix(g["scale_factor_ppm"] * PPM,
                                     g["misalignment_mrad"] * MRAD, rng)

        self.accel_bias_const = rng.normal(0.0, a["bias_sigma_mg"] * MG, 3)
        self.accel_bi_sigma = a["bias_instability_mg"] * MG
        self.accel_bi_tau = a["bias_corr_time_s"]
        self.accel_vrw = a["vrw_mpsph"] * MPSPH
        self.accel_M = _sensor_matrix(a["scale_factor_ppm"] * PPM,
                                      a["misalignment_mrad"] * MRAD, rng)

        self.gyro_bias = None    # (N, 3) total bias history [rad/s], set by corrupt()
        self.accel_bias = None   # (N, 3) total bias history [m/s^2]

    def corrupt(self, dtheta, dv):
        """Apply the errors to ideal increments. Returns (dtheta_meas, dv_meas)."""
        n, dt, rng = len(dtheta), self.dt, self.rng
        self.gyro_bias = self.gyro_bias_const + gauss_markov(
            n, self.gyro_bi_sigma, self.gyro_bi_tau, dt, rng)
        self.accel_bias = self.accel_bias_const + gauss_markov(
            n, self.accel_bi_sigma, self.accel_bi_tau, dt, rng)

        sq = math.sqrt(dt)
        dtheta_m = (dtheta @ self.gyro_M.T + self.gyro_bias * dt
                    + rng.normal(0.0, self.gyro_arw * sq, (n, 3)))
        dv_m = (dv @ self.accel_M.T + self.accel_bias * dt
                + rng.normal(0.0, self.accel_vrw * sq, (n, 3)))
        return dtheta_m, dv_m
