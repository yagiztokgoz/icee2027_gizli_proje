"""WGS84 constants and unit conversions (all internal quantities are SI)."""
import math

import numpy as np

WGS84_A = 6378137.0                      # semi-major axis [m]
WGS84_F = 1.0 / 298.257223563            # flattening
WGS84_E2 = WGS84_F * (2.0 - WGS84_F)     # first eccentricity squared
WGS84_MU = 3.986004418e14                # gravitational constant [m^3/s^2]
WGS84_J2 = 1.082627e-3                   # second zonal harmonic
OMEGA_IE = 7.292115e-5                   # Earth rotation rate [rad/s]
OMEGA_IE_VEC = np.array([0.0, 0.0, OMEGA_IE])
G0 = 9.80665                             # standard gravity [m/s^2]

DEG = math.pi / 180.0                    # deg -> rad
DPH = DEG / 3600.0                       # deg/h -> rad/s
DPSH = DEG / 60.0                        # deg/sqrt(h) -> rad/sqrt(s)
MPSPH = 1.0 / 60.0                       # m/s/sqrt(h) -> m/s/sqrt(s)
MG = 1e-3 * G0                           # milli-g -> m/s^2
PPM = 1e-6
MRAD = 1e-3
