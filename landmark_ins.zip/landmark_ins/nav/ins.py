"""ECEF strapdown INS mechanization (see docs/CONVENTIONS.md).

Optionally aided by a barometric altimeter through the classical third-order
baro-inertial vertical-channel damping loop (the standard way every real INS
keeps its vertical channel from diverging).
"""
from dataclasses import dataclass

import numpy as np

from .constants import DEG, G0, OMEGA_IE_VEC, WGS84_A
from .earth import coriolis_term, gravity_ecef
from .frames import (dcm_ned_to_ecef, ecef_to_geodetic, orthonormalize,
                     rotvec_to_dcm, up_vector_ecef)


class BaroVerticalDamping:
    """Gains of the third-order baro-inertial loop with a triple pole at -1/tau.

    Error dynamics: h' = v - K1 e ;  v' = (2g/R) h + ... - K2 e - z ;  z' = K3 e
    with e = h_ins - h_baro and z an estimate of the vertical accelerometer bias.
    Characteristic polynomial: s^3 + K1 s^2 + (K2 - 2g/R) s + K3 = (s + 1/tau)^3.
    """

    def __init__(self, time_constant_s, sample_interval_s):
        tau = time_constant_s
        self.k1 = 3.0 / tau
        self.k2 = 3.0 / tau ** 2 + 2.0 * G0 / WGS84_A
        self.k3 = 1.0 / tau ** 3
        self.dt = sample_interval_s


@dataclass
class BaroAiding:
    indices: np.ndarray            # IMU state indices at which a baro sample exists (ascending)
    heights: np.ndarray            # measured ellipsoidal heights [m]
    damping: BaroVerticalDamping


class StrapdownEcef:
    """Single-step ECEF mechanization. State: r_e, v_e, C_be (+ vertical bias estimate)."""

    def __init__(self, r_e, v_e, C_be, dt):
        self.r = np.array(r_e, dtype=float)
        self.v = np.array(v_e, dtype=float)
        self.C = np.array(C_be, dtype=float)
        self.dt = dt
        self._E_half = rotvec_to_dcm(-OMEGA_IE_VEC * dt / 2.0)   # exp(-[w_ie x] dt/2)
        self._E_full = self._E_half @ self._E_half               # exp(-[w_ie x] dt)
        self._steps = 0
        self._z = 0.0                    # vertical accelerometer-bias estimate [m/s^2]
        self._up = np.zeros(3)

    def step(self, dtheta, dv):
        """Advance one IMU interval with body-frame increments (rad, m/s)."""
        dt = self.dt
        C_old = self.C
        C_mid = self._E_half @ C_old @ rotvec_to_dcm(0.5 * dtheta)
        self.C = self._E_full @ C_old @ rotvec_to_dcm(dtheta)
        r_mid = self.r + 0.5 * self.v * dt
        v_new = self.v + C_mid @ dv + (gravity_ecef(r_mid) - coriolis_term(self.v)) * dt
        if self._z != 0.0:
            v_new -= self._z * self._up * dt
        self.r = self.r + 0.5 * (self.v + v_new) * dt
        self.v = v_new
        self._steps += 1
        if self._steps % 1000 == 0:
            self.C = orthonormalize(self.C)

    def baro_update(self, height_measured, damping):
        """Apply one baro-inertial damping correction along the local vertical."""
        lat, lon, h = ecef_to_geodetic(self.r)
        up = up_vector_ecef(lat, lon)
        e = h - height_measured
        self.r -= damping.k1 * e * damping.dt * up
        self.v -= damping.k2 * e * damping.dt * up
        self._z += damping.k3 * e * damping.dt
        self._up = up


def run_ins(r0, v0, C0, dtheta, dv, dt, baro=None):
    """Propagate the INS over all increments.

    Returns (r, v, C) histories, each with len(dtheta) + 1 samples.
    `baro`: optional BaroAiding. Its state-0 sample is ignored.
    """
    n = len(dtheta)
    ins = StrapdownEcef(r0, v0, C0, dt)
    r = np.empty((n + 1, 3))
    v = np.empty((n + 1, 3))
    C = np.empty((n + 1, 3, 3))
    r[0], v[0], C[0] = ins.r, ins.v, ins.C

    ptr = 0
    if baro is not None:
        while ptr < len(baro.indices) and baro.indices[ptr] < 1:
            ptr += 1
    for k in range(n):
        ins.step(dtheta[k], dv[k])
        if baro is not None and ptr < len(baro.indices) and baro.indices[ptr] == k + 1:
            ins.baro_update(baro.heights[ptr], baro.damping)
            ptr += 1
        r[k + 1], v[k + 1], C[k + 1] = ins.r, ins.v, ins.C
    return r, v, C


def perturb_initial_state(truth, init_cfg, rng):
    """Sample initial INS errors around the true initial state.

    Errors are 1-sigma Gaussian in the local NED frame at the start point:
    position [m], velocity [m/s], and a small rotation vector [deg] about the
    N, E, D axes (tilt_N, tilt_E, heading error).
    Returns (r0, v0, C0, injected) where `injected` holds the sampled errors.
    """
    lat, lon, _ = truth.lla[0]
    C_ne = dcm_ned_to_ecef(lat, lon)
    dr_n = rng.normal(0.0, 1.0, 3) * np.asarray(init_cfg["position_ned_m"], dtype=float)
    dv_n = rng.normal(0.0, 1.0, 3) * np.asarray(init_cfg["velocity_ned_mps"], dtype=float)
    eps_n = rng.normal(0.0, 1.0, 3) * np.asarray(init_cfg["attitude_ned_deg"], dtype=float) * DEG
    r0 = truth.r_e[0] + C_ne @ dr_n
    v0 = truth.v_e[0] + C_ne @ dv_n
    C0 = rotvec_to_dcm(C_ne @ eps_n) @ truth.C_be[0]
    return r0, v0, C0, {"position_ned_m": dr_n, "velocity_ned_mps": dv_n,
                        "attitude_ned_rad": eps_n}
