"""Frame transformations and rotation utilities. See docs/CONVENTIONS.md.

Naming rule used everywhere: `C_xy` rotates a vector FROM frame x TO frame y,
i.e. v_y = C_xy @ v_x.   (C_be: body->ECEF, C_ne: NED->ECEF, C_en: ECEF->NED.)
"""
import math

import numpy as np

from .constants import WGS84_A, WGS84_E2


# ---------------------------------------------------------------------------
# Basic rotation tools
# ---------------------------------------------------------------------------
def skew(v):
    """Skew-symmetric matrix such that skew(a) @ b = a x b."""
    return np.array([[0.0, -v[2], v[1]],
                     [v[2], 0.0, -v[0]],
                     [-v[1], v[0], 0.0]])


def rotvec_to_dcm(phi):
    """Exponential map: rotation vector -> rotation matrix (Rodrigues)."""
    a2 = phi[0] * phi[0] + phi[1] * phi[1] + phi[2] * phi[2]
    K = skew(phi)
    if a2 < 1e-16:
        return np.eye(3) + K + 0.5 * (K @ K)
    a = math.sqrt(a2)
    return np.eye(3) + (math.sin(a) / a) * K + ((1.0 - math.cos(a)) / a2) * (K @ K)


def dcm_to_rotvec(C):
    """Logarithmic map: rotation matrix -> rotation vector (angle < pi)."""
    w = 0.5 * np.array([C[2, 1] - C[1, 2], C[0, 2] - C[2, 0], C[1, 0] - C[0, 1]])
    s = math.sqrt(w[0] * w[0] + w[1] * w[1] + w[2] * w[2])   # sin(angle)
    c = 0.5 * (C[0, 0] + C[1, 1] + C[2, 2] - 1.0)             # cos(angle)
    if s < 1e-12:
        return w
    a = math.atan2(s, c)
    return (a / s) * w


def orthonormalize(C):
    """Project a matrix onto SO(3)."""
    u, _, vt = np.linalg.svd(C)
    return u @ vt


def wrap_pi(a):
    """Wrap angle(s) to [-pi, pi)."""
    return (np.asarray(a) + math.pi) % (2.0 * math.pi) - math.pi


# ---------------------------------------------------------------------------
# Geodetic <-> ECEF (WGS84)
# ---------------------------------------------------------------------------
def curvature_radii(lat):
    """Meridian radius M and prime-vertical radius N at geodetic latitude(s) [m]."""
    s2 = np.sin(lat) ** 2
    w = np.sqrt(1.0 - WGS84_E2 * s2)
    return WGS84_A * (1.0 - WGS84_E2) / (w ** 3), WGS84_A / w


def geodetic_to_ecef(lat, lon, h):
    """WGS84 geodetic (rad, rad, m) -> ECEF position (m)."""
    s, c = math.sin(lat), math.cos(lat)
    n = WGS84_A / math.sqrt(1.0 - WGS84_E2 * s * s)
    return np.array([(n + h) * c * math.cos(lon),
                     (n + h) * c * math.sin(lon),
                     (n * (1.0 - WGS84_E2) + h) * s])


def ecef_to_geodetic(r):
    """ECEF position (m) -> (lat rad, lon rad, ellipsoidal height m)."""
    x, y, z = r[0], r[1], r[2]
    p = math.hypot(x, y)
    lon = math.atan2(y, x)
    lat = math.atan2(z, p * (1.0 - WGS84_E2))
    for _ in range(10):
        s = math.sin(lat)
        n = WGS84_A / math.sqrt(1.0 - WGS84_E2 * s * s)
        h = p / math.cos(lat) - n
        lat_new = math.atan2(z, p * (1.0 - WGS84_E2 * n / (n + h)))
        done = abs(lat_new - lat) < 1e-15
        lat = lat_new
        if done:
            break
    s = math.sin(lat)
    n = WGS84_A / math.sqrt(1.0 - WGS84_E2 * s * s)
    h = p / math.cos(lat) - n
    return lat, lon, h


def ecef_to_geodetic_array(r):
    """Vectorized ecef_to_geodetic: (N, 3) -> (N, 3) = [lat, lon, h]."""
    r = np.asarray(r, dtype=float)
    x, y, z = r[:, 0], r[:, 1], r[:, 2]
    p = np.hypot(x, y)
    lon = np.arctan2(y, x)
    lat = np.arctan2(z, p * (1.0 - WGS84_E2))
    for _ in range(8):
        s = np.sin(lat)
        n = WGS84_A / np.sqrt(1.0 - WGS84_E2 * s * s)
        h = p / np.cos(lat) - n
        lat = np.arctan2(z, p * (1.0 - WGS84_E2 * n / (n + h)))
    s = np.sin(lat)
    n = WGS84_A / np.sqrt(1.0 - WGS84_E2 * s * s)
    h = p / np.cos(lat) - n
    return np.column_stack([lat, lon, h])


def dcm_ecef_to_ned(lat, lon):
    """C_en: rotates ECEF vectors into the local NED frame."""
    sl, cl = math.sin(lat), math.cos(lat)
    so, co = math.sin(lon), math.cos(lon)
    return np.array([[-sl * co, -sl * so, cl],
                     [-so, co, 0.0],
                     [-cl * co, -cl * so, -sl]])


def dcm_ned_to_ecef(lat, lon):
    """C_ne: rotates local NED vectors into ECEF."""
    return dcm_ecef_to_ned(lat, lon).T


def dcm_ecef_to_ned_array(lat, lon):
    """Vectorized C_en for arrays of latitude/longitude: (N,) -> (N, 3, 3)."""
    sl, cl, so, co = np.sin(lat), np.cos(lat), np.sin(lon), np.cos(lon)
    C = np.zeros((len(lat), 3, 3))
    C[:, 0, 0], C[:, 0, 1], C[:, 0, 2] = -sl * co, -sl * so, cl
    C[:, 1, 0], C[:, 1, 1] = -so, co
    C[:, 2, 0], C[:, 2, 1], C[:, 2, 2] = -cl * co, -cl * so, -sl
    return C


def up_vector_ecef(lat, lon):
    """Unit vector of the ellipsoid normal (local 'up') expressed in ECEF."""
    cl = math.cos(lat)
    return np.array([cl * math.cos(lon), cl * math.sin(lon), math.sin(lat)])


# ---------------------------------------------------------------------------
# Euler angles (ZYX, body -> NED)
# ---------------------------------------------------------------------------
def euler_to_dcm(roll, pitch, yaw):
    """C_bn (body -> NED) from roll, pitch, yaw [rad]: Rz(yaw) Ry(pitch) Rx(roll).

    Pitch is positive nose-up; roll is positive right-wing-down.
    """
    sr, cr = math.sin(roll), math.cos(roll)
    sp, cp = math.sin(pitch), math.cos(pitch)
    sy, cy = math.sin(yaw), math.cos(yaw)
    return np.array([
        [cp * cy, -cr * sy + sr * sp * cy, sr * sy + cr * sp * cy],
        [cp * sy, cr * cy + sr * sp * sy, -sr * cy + cr * sp * sy],
        [-sp, sr * cp, cr * cp]])


def dcm_to_euler(C_bn):
    """Roll, pitch, yaw [rad] from C_bn."""
    roll = math.atan2(C_bn[2, 1], C_bn[2, 2])
    pitch = -math.asin(max(-1.0, min(1.0, C_bn[2, 0])))
    yaw = math.atan2(C_bn[1, 0], C_bn[0, 0])
    return roll, pitch, yaw
