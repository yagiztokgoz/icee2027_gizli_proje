"""Earth model: gravity and Coriolis terms in ECEF."""
import math

import numpy as np

from .constants import OMEGA_IE, WGS84_A, WGS84_J2, WGS84_MU


def gravity_ecef(r):
    """Plumb-bob gravity (J2 gravitation + centrifugal) in ECEF [m/s^2]. r: (3,)."""
    x, y, z = r[0], r[1], r[2]
    r2 = x * x + y * y + z * z
    rn = math.sqrt(r2)
    k = 1.5 * WGS84_J2 * (WGS84_A * WGS84_A) / r2
    zr2 = z * z / r2
    f = -WGS84_MU / (rn * r2)
    w2 = OMEGA_IE * OMEGA_IE
    return np.array([f * x * (1.0 + k * (1.0 - 5.0 * zr2)) + w2 * x,
                     f * y * (1.0 + k * (1.0 - 5.0 * zr2)) + w2 * y,
                     f * z * (1.0 + k * (3.0 - 5.0 * zr2))])


def gravity_ecef_array(r):
    """Vectorized gravity_ecef. r: (N, 3) -> (N, 3)."""
    x, y, z = r[:, 0], r[:, 1], r[:, 2]
    r2 = x * x + y * y + z * z
    rn = np.sqrt(r2)
    k = 1.5 * WGS84_J2 * (WGS84_A * WGS84_A) / r2
    zr2 = z * z / r2
    f = -WGS84_MU / (rn * r2)
    w2 = OMEGA_IE * OMEGA_IE
    return np.column_stack([f * x * (1.0 + k * (1.0 - 5.0 * zr2)) + w2 * x,
                            f * y * (1.0 + k * (1.0 - 5.0 * zr2)) + w2 * y,
                            f * z * (1.0 + k * (3.0 - 5.0 * zr2))])


def coriolis_term(v):
    """2 * w_ie x v for w_ie = [0, 0, OMEGA_IE]. v: (3,)."""
    return np.array([-2.0 * OMEGA_IE * v[1], 2.0 * OMEGA_IE * v[0], 0.0])


def coriolis_term_array(v):
    """Vectorized coriolis_term. v: (N, 3) -> (N, 3)."""
    out = np.zeros_like(v)
    out[:, 0] = -2.0 * OMEGA_IE * v[:, 1]
    out[:, 1] = 2.0 * OMEGA_IE * v[:, 0]
    return out
