"""Barometric altimeter simulation.

Measurement = true ellipsoidal height + slowly varying bias + white noise.
The bias is a first-order Gauss-Markov process (stationary sigma `bias_sigma_m`,
correlation time `bias_corr_time_s`).
"""
from dataclasses import dataclass

import numpy as np

from .noise import gauss_markov


@dataclass
class BaroMeasurements:
    indices: np.ndarray    # IMU sample indices of the baro samples
    heights: np.ndarray    # measured heights [m]
    bias: np.ndarray       # true bias at each sample [m] (for analysis only)


class BaroModel:
    def __init__(self, baro_cfg, imu_rate_hz, rng):
        self.cfg = baro_cfg
        self.imu_dt = 1.0 / imu_rate_hz
        self.stride = int(round(imu_rate_hz / baro_cfg["rate_hz"]))
        self.rng = rng

    @property
    def sample_interval_s(self):
        return self.stride * self.imu_dt

    def measure(self, true_height):
        """true_height: (N,) ellipsoidal height at every IMU sample."""
        idx = np.arange(0, len(true_height), self.stride)
        bias = gauss_markov(len(idx), self.cfg["bias_sigma_m"], self.cfg["bias_corr_time_s"],
                            self.sample_interval_s, self.rng, dim=1)[:, 0]
        noise = self.rng.normal(0.0, self.cfg["noise_m"], len(idx))
        return BaroMeasurements(indices=idx, heights=true_height[idx] + bias + noise, bias=bias)
