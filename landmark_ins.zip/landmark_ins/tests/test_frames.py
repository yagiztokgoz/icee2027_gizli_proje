import numpy as np

from nav.constants import DEG
from nav.frames import (curvature_radii, dcm_ecef_to_ned, dcm_ecef_to_ned_array, dcm_to_euler,
                        dcm_to_rotvec, ecef_to_geodetic, ecef_to_geodetic_array, euler_to_dcm,
                        geodetic_to_ecef, rotvec_to_dcm, up_vector_ecef, wrap_pi)


def test_geodetic_roundtrip_scalar_and_array():
    pts = [(39.0, 32.5, 2500.0), (-45.0, 170.0, 10.0), (80.0, -60.0, 1e4), (0.0, 0.0, 0.0)]
    r = np.array([geodetic_to_ecef(a * DEG, b * DEG, h) for a, b, h in pts])
    arr = ecef_to_geodetic_array(r)
    for (lat, lon, h), row, rr in zip(pts, arr, r):
        for lla in (ecef_to_geodetic(rr), row):
            assert abs(lla[0] - lat * DEG) < 1e-11
            assert abs(lla[1] - lon * DEG) < 1e-11
            assert abs(lla[2] - h) < 1e-5


def test_rotvec_roundtrip():
    rng = np.random.default_rng(0)
    for scale in [1e-9, 1e-4, 0.1, 2.0]:
        phi = rng.normal(size=3)
        phi *= scale / np.linalg.norm(phi)
        C = rotvec_to_dcm(phi)
        assert np.allclose(C @ C.T, np.eye(3), atol=1e-14)
        assert np.allclose(dcm_to_rotvec(C), phi, atol=1e-13, rtol=1e-10)


def test_ned_axes_point_where_they_should():
    lat, lon = 39.0 * DEG, 32.5 * DEG
    C_en = dcm_ecef_to_ned(lat, lon)
    r0 = geodetic_to_ecef(lat, lon, 0.0)
    # 'up' = ellipsoid normal: raising the height moves along -D
    d = C_en @ (geodetic_to_ecef(lat, lon, 100.0) - r0)
    assert np.allclose(d, [0, 0, -100.0], atol=1e-8)
    # moving to larger latitude is 'north', larger longitude is 'east'
    d = C_en @ (geodetic_to_ecef(lat + 1e-6, lon, 0.0) - r0)
    assert d[0] > 0 and abs(d[1]) < 1e-9 and abs(d[2]) < 1e-3
    d = C_en @ (geodetic_to_ecef(lat, lon + 1e-6, 0.0) - r0)
    assert d[1] > 0 and abs(d[0]) < 1e-3 * d[1]     # the parallel curves only at 2nd order
    # up vector agrees with the NED frame
    assert np.allclose(C_en @ up_vector_ecef(lat, lon), [0, 0, -1], atol=1e-12)


def test_ned_array_matches_scalar():
    lat, lon = np.array([0.3, -0.5]), np.array([1.0, 2.5])
    C = dcm_ecef_to_ned_array(lat, lon)
    for k in range(2):
        assert np.allclose(C[k], dcm_ecef_to_ned(lat[k], lon[k]))
        assert np.allclose(C[k] @ C[k].T, np.eye(3), atol=1e-14)


def test_euler_conventions():
    angles = (0.3, -0.2, 2.5)
    assert np.allclose(dcm_to_euler(euler_to_dcm(*angles)), angles)
    # level, heading east: body x -> East, body y -> South, body z -> Down
    C = euler_to_dcm(0.0, 0.0, 90.0 * DEG)
    assert np.allclose(C @ [1, 0, 0], [0, 1, 0], atol=1e-12)
    assert np.allclose(C @ [0, 0, 1], [0, 0, 1], atol=1e-12)
    # positive pitch = nose up (body x gets a negative Down component)
    assert (euler_to_dcm(0.0, 0.1, 0.0) @ [1, 0, 0])[2] < 0
    # positive roll = right wing down (body y gets a positive Down component)
    assert (euler_to_dcm(0.1, 0.0, 0.0) @ [0, 1, 0])[2] > 0


def test_curvature_radii_and_wrap():
    M, N = curvature_radii(np.array([0.0, 90.0 * DEG]))
    assert abs(M[0] - 6335439.3) < 1.0 and abs(N[0] - 6378137.0) < 1e-6
    assert abs(N[1] - 6399593.6) < 1.0
    assert np.isclose(wrap_pi(3.5 * np.pi), -0.5 * np.pi)
