import copy

import pytest

from nav.config import ConfigError, load_config, validate_config


def test_default_config_is_valid(default_cfg):
    validate_config(default_cfg)
    assert len(default_cfg["landmarks"]) >= 1


@pytest.mark.parametrize("mutate, fragment", [
    (lambda c: c["route"].__setitem__("speed_mps", -5.0), "route.speed_mps"),
    (lambda c: c["landmarks"].append(dict(c["landmarks"][0])), "duplicate landmark id"),
    (lambda c: c["landmarks"][0].__setitem__("lat_deg", 95.0), "latitude"),
    (lambda c: c["baro"].__setitem__("rate_hz", 7.0), "integer multiple"),
    (lambda c: c["camera"].__setitem__("fov_horizontal_deg", 0.0), "camera.fov_horizontal_deg"),
    (lambda c: c["initial_errors"].__setitem__("position_ned_m", [1.0, 2.0]), "list of 3"),
    (lambda c: c["route"].__setitem__("waypoints", []), "non-empty"),
    (lambda c: c.pop("imu"), "imu"),
    (lambda c: c["baro"].__setitem__("enabled", "yes"), "baro.enabled"),
])
def test_invalid_configs_are_rejected_with_a_clear_message(default_cfg, mutate, fragment):
    cfg = copy.deepcopy(default_cfg)
    mutate(cfg)
    with pytest.raises(ConfigError) as exc:
        validate_config(cfg)
    assert fragment in str(exc.value)


def test_disabled_baro_needs_no_baro_parameters(default_cfg):
    cfg = copy.deepcopy(default_cfg)
    cfg["baro"] = {"enabled": False}
    validate_config(cfg)


def test_load_config_reads_the_default_file():
    assert load_config()["simulation"]["imu_rate_hz"] > 0
