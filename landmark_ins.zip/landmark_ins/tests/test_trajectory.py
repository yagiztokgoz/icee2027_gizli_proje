import numpy as np

from nav.constants import DEG, G0
from nav.frames import geodetic_to_ecef


def test_route_completes_and_holds_speed_and_height(default_cfg, default_truth):
    cfg, truth = default_cfg, default_truth
    assert truth.completed
    speed = np.linalg.norm(truth.v_e, axis=1)
    assert np.allclose(speed, cfg["route"]["speed_mps"], rtol=1e-6)
    assert np.max(np.abs(truth.lla[:, 2] - 2500.0)) < 5.0


def test_body_x_axis_follows_velocity_and_dcm_is_orthonormal(default_truth):
    truth = default_truth
    x_b = truth.C_be[:, :, 0]
    v_hat = truth.v_e / np.linalg.norm(truth.v_e, axis=1, keepdims=True)
    assert np.max(np.linalg.norm(x_b - v_hat, axis=1)) < 1e-6   # no angle of attack / sideslip
    assert np.max(np.abs(truth.C_be @ truth.C_be.transpose(0, 2, 1) - np.eye(3))) < 1e-12


def test_bank_limit_and_coordinated_turn(default_cfg, default_truth):
    cfg, truth = default_cfg, default_truth
    bank = truth.euler[:, 0]
    assert np.max(np.abs(bank)) <= cfg["route"]["max_bank_deg"] * DEG + 1e-9
    assert np.max(np.abs(bank)) > 20 * DEG                      # the route does contain turns
    # steady-state turn rate matches g*tan(bank)/V
    yaw = np.unwrap(truth.euler[:, 2])
    rate = np.gradient(yaw, truth.dt)
    k = int(np.argmax(np.abs(bank)))
    expected = G0 * np.tan(bank[k]) / cfg["route"]["speed_mps"]
    assert abs(rate[k] - expected) < 2e-3


def test_waypoints_are_reached(default_cfg, default_truth):
    cfg, truth = default_cfg, default_truth
    # the aircraft passes within the acceptance radius of every waypoint
    for w in cfg["route"]["waypoints"]:
        wp = geodetic_to_ecef(w[0] * DEG, w[1] * DEG, w[2])
        assert np.min(np.linalg.norm(truth.r_e - wp, axis=1)) < cfg["route"]["acceptance_radius_m"] * 1.5


def test_every_default_landmark_is_near_the_route(default_cfg, default_truth):
    cfg, truth = default_cfg, default_truth
    for lm in cfg["landmarks"]:
        p = geodetic_to_ecef(lm["lat_deg"] * DEG, lm["lon_deg"] * DEG, 2500.0)   # same height as route
        assert np.min(np.linalg.norm(truth.r_e - p, axis=1)) < 600.0   # offsets are <= 400 m
