import copy

import numpy as np

from analysis.report import build_report, landmark_geometry
from sim.pipeline import run_scenario


def short_turning_cfg(short_cfg):
    cfg = copy.deepcopy(short_cfg)
    cfg["route"]["initial_heading_deg"] = 90.0       # includes a turn
    return cfg


def test_pipeline_runs_and_is_deterministic(short_cfg):
    cfg = short_turning_cfg(short_cfg)
    a = run_scenario(cfg, verbose=False)
    b = run_scenario(cfg, verbose=False)
    c = run_scenario(cfg, seed=99, verbose=False)
    assert set(a.cases) == {"unaided", "baro_damped"}
    n = len(a.truth)
    for case in a.cases.values():
        assert case.r.shape == (n, 3) and case.errors["horizontal_m"].shape == (n,)
    assert a.ideal_check_max_error_m < 1e-3
    assert np.array_equal(a.cases["unaided"].r, b.cases["unaided"].r)          # same seed, same result
    assert not np.allclose(a.cases["unaided"].r, c.cases["unaided"].r)          # different seed differs


def test_both_cases_share_the_same_imu_and_initial_errors(short_cfg):
    res = run_scenario(short_turning_cfg(short_cfg), verbose=False)
    u, d = res.cases["unaided"].errors, res.cases["baro_damped"].errors
    assert np.allclose(u["position_ned_m"][0], d["position_ned_m"][0])          # same start
    assert np.allclose(u["horizontal_m"][:200], d["horizontal_m"][:200], atol=1.0)


def test_baro_can_be_disabled(short_cfg):
    cfg = copy.deepcopy(short_cfg)
    cfg["baro"] = {"enabled": False}
    res = run_scenario(cfg, verbose=False)
    assert list(res.cases) == ["unaided"]
    assert "INS only" in build_report(res)


def test_unaided_error_grows_with_time(short_cfg):
    res = run_scenario(short_turning_cfg(short_cfg), verbose=False, verify=False)
    h = res.cases["unaided"].errors["horizontal_m"]
    assert h[-1] > h[0] and h[-1] > 20.0


def test_report_flags_a_landmark_that_can_never_be_seen(short_cfg):
    cfg = short_turning_cfg(short_cfg)
    cfg["landmarks"] = [dict(cfg["landmarks"][0], id="FAR", lat_deg=36.0, lon_deg=30.0)]
    res = run_scenario(cfg, verbose=False, verify=False)
    assert landmark_geometry(res)[0]["windows"] == []
    text = build_report(res)
    assert "NEVER VISIBLE" in text and "NOT VISIBLE" in text


def test_report_contains_definitions_and_ok_verdict_for_the_default_scenario(default_cfg):
    cfg = copy.deepcopy(default_cfg)
    cfg["simulation"]["max_duration_s"] = 400.0       # LM1 is passed at ~280 s
    cfg["landmarks"] = cfg["landmarks"][:1]
    res = run_scenario(cfg, verbose=False, verify=False)
    text = build_report(res)
    assert "horizontal = sqrt(dNorth^2 + dEast^2)" in text
    assert "OK: every landmark is seen" in text
