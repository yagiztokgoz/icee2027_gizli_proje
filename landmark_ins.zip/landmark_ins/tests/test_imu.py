import copy
import math

import numpy as np

from nav.constants import DEG, DPH, MG
from nav.imu import ImuErrorModel, ideal_imu
from nav.ins import run_ins
from nav.noise import gauss_markov
from nav.trajectory import generate_truth


def _noise_only_cfg(default_cfg):
    imu = copy.deepcopy(default_cfg["imu"])
    for sensor in ("gyro", "accel"):
        for key in imu[sensor]:
            if key.startswith(("bias_sigma", "bias_instability", "scale_factor", "misalignment")):
                imu[sensor][key] = 0.0
    return imu


def test_ideal_imu_reproduces_truth_through_a_turn(short_cfg):
    cfg = copy.deepcopy(short_cfg)
    cfg["route"]["initial_heading_deg"] = 90.0       # forces a turn toward the first waypoint
    truth = generate_truth(cfg)
    assert np.max(np.abs(truth.euler[:, 0])) > 20 * DEG
    dtheta, dv = ideal_imu(truth)
    r, v, C = run_ins(truth.r_e[0], truth.v_e[0], truth.C_be[0], dtheta, dv, truth.dt)
    assert np.max(np.linalg.norm(r - truth.r_e, axis=1)) < 1e-4
    assert np.max(np.linalg.norm(v - truth.v_e, axis=1)) < 1e-6
    assert np.max(np.abs(C - truth.C_be)) < 1e-9


def test_random_walk_units_arw_and_vrw(default_cfg):
    """White-noise increments must have std = ARW*sqrt(dt), VRW*sqrt(dt) with the unit conversions right."""
    dt, n = 0.01, 400_000
    imu = ImuErrorModel(_noise_only_cfg(default_cfg), dt, np.random.default_rng(3))
    dth, dv = imu.corrupt(np.zeros((n, 3)), np.zeros((n, 3)))
    g, a = default_cfg["imu"]["gyro"], default_cfg["imu"]["accel"]
    # 0.1 deg/sqrt(h) = 0.1*pi/180/60 rad/sqrt(s)
    assert math.isclose(imu.gyro_arw, g["arw_dpsh"] * math.pi / 180 / 60, rel_tol=1e-12)
    assert np.allclose(dth.std(axis=0), imu.gyro_arw * math.sqrt(dt), rtol=0.02)
    assert np.allclose(dv.std(axis=0), a["vrw_mpsph"] / 60.0 * math.sqrt(dt), rtol=0.02)


def test_turn_on_bias_statistics_and_units(default_cfg):
    g, a = default_cfg["imu"]["gyro"], default_cfg["imu"]["accel"]
    gyro = np.array([ImuErrorModel(default_cfg["imu"], 0.01, np.random.default_rng(s)).gyro_bias_const
                     for s in range(3000)])
    accel = np.array([ImuErrorModel(default_cfg["imu"], 0.01, np.random.default_rng(s)).accel_bias_const
                      for s in range(3000)])
    assert np.allclose(gyro.std(axis=0), g["bias_sigma_dph"] * DPH, rtol=0.06)
    assert np.allclose(accel.std(axis=0), a["bias_sigma_mg"] * MG, rtol=0.06)
    assert abs(g["bias_sigma_dph"] * DPH - 4.848e-6) < 1e-8     # 1 deg/h = 4.848e-6 rad/s
    assert abs(a["bias_sigma_mg"] * MG - 9.80665e-3) < 1e-9


def test_gauss_markov_stationary_variance_and_correlation():
    dt, tau, sigma = 1.0, 100.0, 2.0
    x = gauss_markov(200_000, sigma, tau, dt, np.random.default_rng(0), dim=1)[:, 0]
    assert abs(x.std() / sigma - 1.0) < 0.1
    corr = np.corrcoef(x[:-1], x[1:])[0, 1]
    assert abs(corr - math.exp(-dt / tau)) < 0.01


def test_sensor_matrix_is_close_to_identity_with_small_errors(default_cfg):
    imu = ImuErrorModel(default_cfg["imu"], 0.01, np.random.default_rng(5))
    for M in (imu.gyro_M, imu.accel_M):
        assert np.max(np.abs(M - np.eye(3))) < 2e-3
