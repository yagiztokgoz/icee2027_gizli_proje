import numpy as np

from analysis.errors import navigation_errors
from nav.frames import dcm_ned_to_ecef, geodetic_to_ecef, rotvec_to_dcm
from nav.ins import perturb_initial_state
from nav.trajectory import generate_truth


def test_zero_error_when_estimate_equals_truth(default_truth):
    t = default_truth
    e = navigation_errors(t, t.r_e, t.v_e, t.C_be)
    for key in ("position_ned_m", "velocity_ned_mps", "attitude_ned_rad", "horizontal_m", "height_m"):
        assert np.max(np.abs(e[key])) < 1e-6


def test_injected_initial_errors_are_recovered(short_cfg):
    truth = generate_truth(short_cfg)
    r0, v0, C0, inj = perturb_initial_state(truth, short_cfg["initial_errors"], np.random.default_rng(7))
    r, v, C = truth.r_e.copy(), truth.v_e.copy(), truth.C_be.copy()
    r[0], v[0], C[0] = r0, v0, C0
    e = navigation_errors(truth, r, v, C)
    assert np.allclose(e["position_ned_m"][0], inj["position_ned_m"], atol=1e-4)
    assert np.allclose(e["velocity_ned_mps"][0], inj["velocity_ned_mps"], atol=1e-9)
    assert np.allclose(e["attitude_ned_rad"][0], inj["attitude_ned_rad"], atol=1e-12)


def test_height_error_is_a_pure_height_difference(default_truth):
    t = default_truth
    k = 5000
    lat, lon, h = t.lla[k]
    r = t.r_e.copy()
    r[k] = geodetic_to_ecef(lat, lon, h + 50.0)
    e = navigation_errors(t, r, t.v_e, t.C_be)
    assert abs(e["height_m"][k] - 50.0) < 1e-6
    assert e["horizontal_m"][k] < 1e-6
    assert abs(e["position_ned_m"][k, 2] + 50.0) < 1e-6        # NED Down component = -height error


def test_no_curvature_artifact_in_height_error_for_large_horizontal_error(default_truth):
    """Regression: a 72 km horizontal error at equal height used to show as a ~400 m 'vertical' error."""
    t = default_truth
    k = 5000
    lat, lon, h = t.lla[k]
    d_lat = 72e3 / 6.37e6
    r = t.r_e.copy()
    r[k] = geodetic_to_ecef(lat + d_lat, lon, h)
    e = navigation_errors(t, r, t.v_e, t.C_be)
    assert abs(e["height_m"][k]) < 1e-6
    assert abs(e["horizontal_m"][k] - 72e3) / 72e3 < 0.01


def test_attitude_error_sign_and_frame(default_truth):
    t = default_truth
    k = 100
    lat, lon, _ = t.lla[k]
    eps_n = np.array([0.0, 0.0, 0.01])                 # positive rotation about Down = heading error
    C = t.C_be.copy()
    C[k] = rotvec_to_dcm(dcm_ned_to_ecef(lat, lon) @ eps_n) @ t.C_be[k]
    e = navigation_errors(t, t.r_e, t.v_e, C)
    assert np.allclose(e["attitude_ned_rad"][k], eps_n, atol=1e-12)
