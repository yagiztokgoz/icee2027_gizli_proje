import numpy as np

from nav.baro import BaroModel
from nav.constants import DEG, OMEGA_IE_VEC
from nav.earth import gravity_ecef
from nav.frames import dcm_ned_to_ecef, ecef_to_geodetic, geodetic_to_ecef
from nav.ins import BaroVerticalDamping, StrapdownEcef

LAT, LON, H = 39.0 * DEG, 32.5 * DEG, 2500.0


def vertical_run(damped, accel_bias_down=0.01, duration=1800.0, dt=0.1, baro_offset=0.0):
    """Stationary INS with a vertical accelerometer bias; returns the height error history."""
    r = geodetic_to_ecef(LAT, LON, H)
    C = dcm_ned_to_ecef(LAT, LON)
    ins = StrapdownEcef(r, np.zeros(3), C, dt)
    dtheta = C.T @ OMEGA_IE_VEC * dt
    dv = (C.T @ (-gravity_ecef(r)) + np.array([0.0, 0.0, accel_bias_down])) * dt
    stride = 10
    damping = BaroVerticalDamping(100.0, stride * dt)
    n = int(duration / dt)
    err = np.zeros(n + 1)
    for k in range(n):
        ins.step(dtheta, dv)
        if damped and (k + 1) % stride == 0:
            ins.baro_update(H + baro_offset, damping)
        err[k + 1] = ecef_to_geodetic(ins.r)[2] - H
    return err


def test_vertical_damping_bounds_an_otherwise_exploding_height_error():
    undamped = vertical_run(False)
    damped = vertical_run(True)
    assert abs(undamped[-1]) > 10e3                    # 1 mg-class bias -> tens of km in 30 min
    assert np.max(np.abs(damped)) < 40.0               # bounded transient
    assert abs(damped[-1]) < 0.1                       # integral term absorbed the bias


def test_damped_height_follows_the_baro_including_its_bias():
    err = vertical_run(True, baro_offset=5.0)
    assert abs(err[-1] - 5.0) < 0.1


def test_damping_gains_give_a_triple_pole():
    d = BaroVerticalDamping(100.0, 1.0)
    a = 2 * 9.80665 / 6378137.0
    poly = np.poly1d([1.0, d.k1, d.k2 - a, d.k3])
    assert np.allclose(np.sort(poly.roots.real), -0.01, atol=2e-4)


def test_baro_model_statistics(default_cfg):
    cfg = default_cfg["baro"]
    n = 2_000_000
    model = BaroModel(cfg, 100.0, np.random.default_rng(1))
    assert model.stride == 10 and abs(model.sample_interval_s - 0.1) < 1e-12
    truth_h = np.full(n, 2500.0)
    m = model.measure(truth_h)
    assert m.indices[0] == 0 and np.all(np.diff(m.indices) == 10)
    noise = m.heights - 2500.0 - m.bias
    assert abs(noise.std() - cfg["noise_m"]) < 0.02
    assert abs(m.bias.std() / cfg["bias_sigma_m"] - 1.0) < 0.5      # ~5 correlation times only: loose
