"""Independent physics tests of the ECEF mechanization.

None of these use `ideal_imu`. Each compares the INS against a closed-form
textbook result, so they would catch sign / convention errors that a
self-consistent generator+mechanization pair cannot.
"""
import math

import numpy as np

from nav.constants import DEG, DPH, OMEGA_IE, OMEGA_IE_VEC, WGS84_A, WGS84_E2
from nav.earth import gravity_ecef, gravity_ecef_array
from nav.frames import (dcm_ecef_to_ned, dcm_ned_to_ecef, ecef_to_geodetic, geodetic_to_ecef,
                        up_vector_ecef)
from nav.ins import StrapdownEcef

LAT, LON, H = 39.0 * DEG, 32.5 * DEG, 2500.0
R_MAG = float(np.linalg.norm(geodetic_to_ecef(LAT, LON, H)))
G_LOCAL = float(np.linalg.norm(gravity_ecef(geodetic_to_ecef(LAT, LON, H))))
OMEGA_S = math.sqrt(G_LOCAL / R_MAG)                         # Schuler frequency [rad/s]


def run_stationary(duration, dt, dr0=(0, 0, 0), dv0=(0, 0, 0), gyro_bias_b=(0, 0, 0),
                   accel_bias_b=(0, 0, 0)):
    """Stationary vehicle, body axes = NED axes, perfect (analytic) IMU plus optional errors.

    Specific force of a vehicle at rest is -gravity; gyros sense the Earth rate.
    Returns (true r, array of INS positions, array of INS velocities).
    """
    r = geodetic_to_ecef(LAT, LON, H)
    C = dcm_ned_to_ecef(LAT, LON)
    ins = StrapdownEcef(r + np.asarray(dr0, float), np.asarray(dv0, float), C, dt)
    dtheta = (C.T @ OMEGA_IE_VEC + np.asarray(gyro_bias_b, float)) * dt
    dv = (C.T @ (-gravity_ecef(r)) + np.asarray(accel_bias_b, float)) * dt
    n = int(round(duration / dt))
    pos, vel = np.empty((n + 1, 3)), np.empty((n + 1, 3))
    pos[0], vel[0] = ins.r, ins.v
    for k in range(n):
        ins.step(dtheta, dv)
        pos[k + 1], vel[k + 1] = ins.r, ins.v
    return r, pos, vel


# --------------------------------------------------------------------------- gravity
def test_gravity_magnitude_and_direction():
    sphi = math.sin(LAT)
    somigliana = 9.780327 * (1 + 0.0053024 * sphi ** 2 - 0.0000058 * math.sin(2 * LAT) ** 2)
    r0 = geodetic_to_ecef(LAT, LON, 0.0)
    g_n = dcm_ecef_to_ned(LAT, LON) @ gravity_ecef(r0)
    assert abs(np.linalg.norm(g_n) - somigliana) < 5e-3
    assert g_n[2] > 9.7 and abs(g_n[0]) < 1e-3 and abs(g_n[1]) < 1e-9   # points Down, no sideways part


def test_gravity_scalar_equals_array():
    rs = np.array([geodetic_to_ecef(LAT, LON, 0.0), geodetic_to_ecef(-0.4, 2.0, 5000.0)])
    assert np.allclose(gravity_ecef_array(rs), [gravity_ecef(x) for x in rs], atol=1e-12)


# --------------------------------------------------------------------------- static / Schuler
def test_stationary_vehicle_stays_put():
    r, pos, vel = run_stationary(3600.0, 0.1)
    assert np.max(np.linalg.norm(pos - r, axis=1)) < 1e-3
    assert np.max(np.linalg.norm(vel, axis=1)) < 1e-6


def test_schuler_oscillation_from_velocity_error():
    """0.1 m/s north velocity error -> position oscillation of amplitude v/w_s, period 84 min."""
    C = dcm_ned_to_ecef(LAT, LON)
    dt = 0.1
    r, pos, _ = run_stationary(2800.0, dt, dv0=C @ [0.1, 0, 0])
    err = np.linalg.norm(pos - r, axis=1)
    assert 0.97 < err.max() / (0.1 / OMEGA_S) < 1.03
    t_peak = err.argmax() * dt
    assert abs(t_peak - math.pi / (2 * OMEGA_S)) < 0.04 * math.pi / (2 * OMEGA_S)


def test_accelerometer_bias_gives_offset_of_two_b_over_ws2():
    """North accel bias b -> error b/ws^2 (1 - cos(ws t)); peak 2b/ws^2 at half a Schuler period."""
    b = 0.01
    r, pos, _ = run_stationary(2700.0, 0.1, accel_bias_b=(b, 0, 0))
    peak = np.linalg.norm(pos - r, axis=1).max()
    assert 0.95 < peak / (2 * b / OMEGA_S ** 2) < 1.05


def test_gyro_bias_gives_linear_drift_of_R_eps():
    """East gyro bias eps -> position error R*eps*(t - sin(ws t)/ws)."""
    eps, t_end, dt = 1.0 * DPH, 1800.0, 0.1
    r, pos, _ = run_stationary(t_end, dt, gyro_bias_b=(0, eps, 0))
    got = np.linalg.norm(pos[-1] - r)
    expected = R_MAG * eps * (t_end - math.sin(OMEGA_S * t_end) / OMEGA_S)
    assert 0.95 < got / expected < 1.05
    assert 30e3 < got < 40e3          # sanity: 1 deg/h is ~111 km/h of Schuler-averaged drift


def test_vertical_channel_is_unstable_with_the_theoretical_time_constant():
    """Height error grows as cosh(t/tau), tau = 1/sqrt(2g/R) ~ 570 s."""
    up = up_vector_ecef(LAT, LON)
    a = 2.0 * G_LOCAL / R_MAG
    t_end = 3.0 / math.sqrt(a)
    r, pos, _ = run_stationary(t_end, 0.1, dr0=1.0 * up)
    h_err = ecef_to_geodetic(pos[-1])[2] - H
    assert 0.97 < h_err / math.cosh(3.0) < 1.03


# --------------------------------------------------------------------------- moving vehicle
def test_eastbound_level_flight_matches_textbook_specific_force():
    """Level flight due east along a parallel at 50 m/s.

    Textbook (Groves) navigation-frame specific force and body rate for body axes = NED axes:
        f_n  = (2 w_ie + w_en) x v_n - g_n,   w_ie = (W cos L, 0, -W sin L),
        w_en = (V/(N+h), 0, -V tan L/(N+h)),  v_n = (0, V, 0)
    Feeding exactly these, the INS must reproduce the analytic ECEF trajectory. A wrong
    Coriolis/transport/Earth-rate sign would produce hundreds of metres of error.
    """
    V, duration, dt = 50.0, 600.0, 0.1
    s, c = math.sin(LAT), math.cos(LAT)
    N = WGS84_A / math.sqrt(1.0 - WGS84_E2 * s * s)
    lam_dot = V / ((N + H) * c)

    def state(t):
        lam = LON + lam_dot * t
        r = np.array([(N + H) * c * math.cos(lam), (N + H) * c * math.sin(lam),
                      (N * (1.0 - WGS84_E2) + H) * s])
        v = V * np.array([-math.sin(lam), math.cos(lam), 0.0])
        return r, v, dcm_ned_to_ecef(LAT, lam)

    g_n = dcm_ecef_to_ned(LAT, LON) @ gravity_ecef(state(0.0)[0])
    w_ie_n = np.array([OMEGA_IE * c, 0.0, -OMEGA_IE * s])
    w_en_n = np.array([V / (N + H), 0.0, -V * math.tan(LAT) / (N + H)])
    v_n = np.array([0.0, V, 0.0])
    f_n = np.cross(2.0 * w_ie_n + w_en_n, v_n) - g_n          # constant in body (= NED) axes
    w_ib_b = w_ie_n + w_en_n                                   # constant body rate

    r0, v0, C0 = state(0.0)
    ins = StrapdownEcef(r0, v0, C0, dt)
    for _ in range(int(round(duration / dt))):
        ins.step(w_ib_b * dt, f_n * dt)
    r1, v1, C1 = state(duration)
    assert np.linalg.norm(ins.r - r1) < 0.05
    assert np.linalg.norm(ins.v - v1) < 1e-3
    assert np.max(np.abs(ins.C - C1)) < 1e-8
    # the Coriolis term alone is ~0.0046 m/s^2 -> ~830 m over 600 s: the test is sensitive to it
    assert abs(f_n[0]) > 0.004
