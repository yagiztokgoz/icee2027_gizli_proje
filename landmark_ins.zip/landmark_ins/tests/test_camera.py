import numpy as np

from nav.camera import CameraModel
from nav.constants import DEG
from nav.frames import dcm_ned_to_ecef, geodetic_to_ecef

LAT, LON, H = 39.0 * DEG, 32.5 * DEG, 2500.0


def make_camera(pitch_deg=-15.0, lever=(0.0, 0.0, 0.0), fov=(30.0, 20.0), max_range=10000.0, yaw_deg=0.0):
    return CameraModel({"mounting_rpy_deg": [0.0, pitch_deg, yaw_deg], "lever_arm_m": list(lever),
                        "fov_horizontal_deg": fov[0], "fov_vertical_deg": fov[1],
                        "max_range_m": max_range})


def view(cam, d_ned):
    """Camera-frame LOS to a landmark placed d_ned (N, E, D) from a level aircraft heading north."""
    C_ne = dcm_ned_to_ecef(LAT, LON)
    r = geodetic_to_ecef(LAT, LON, H)
    return cam.landmark_in_camera(r, C_ne, r + C_ne @ np.asarray(d_ned, float))


def test_boresight_points_where_the_mounting_says():
    cam = make_camera(pitch_deg=-15.0)
    boresight_body = cam.C_bc.T @ [0, 0, 1]
    assert np.allclose(boresight_body, [np.cos(15 * DEG), 0.0, np.sin(15 * DEG)], atol=1e-12)  # 15 deg below the nose
    cam2 = make_camera(pitch_deg=0.0, yaw_deg=20.0)
    assert np.allclose(cam2.C_bc.T @ [0, 0, 1], [np.cos(20 * DEG), np.sin(20 * DEG), 0.0], atol=1e-12)  # right of the nose


def test_landmark_on_boresight_has_zero_az_el():
    cam = make_camera()
    d_c, rng = view(cam, [5000.0, 0.0, 5000.0 * np.tan(15 * DEG)])
    az, el = cam.az_el(d_c)
    assert abs(az) < 1e-12 and abs(el) < 1e-12
    assert abs(rng - 5000.0 / np.cos(15 * DEG)) < 1e-6


def test_az_el_signs():
    cam = make_camera()
    base = [5000.0, 0.0, 5000.0 * np.tan(15 * DEG)]
    az, el = cam.az_el(view(cam, [5000.0, 500.0, base[2]])[0])      # east of a north-heading aircraft = right
    assert az > 0 and abs(el) < 0.01
    az, el = cam.az_el(view(cam, [5000.0, 0.0, base[2] - 500.0])[0])  # higher landmark = positive elevation
    assert el > 0 and abs(az) < 1e-9


def test_field_of_view_and_range_limits():
    cam = make_camera(fov=(30.0, 20.0), max_range=10000.0)
    tan = np.tan
    z = 5000.0 * tan(15 * DEG)
    inside = view(cam, [5000.0, 5000.0 * tan(10 * DEG), z])
    outside_az = view(cam, [5000.0, 5000.0 * tan(20 * DEG), z])
    outside_el = view(cam, [5000.0, 0.0, 5000.0 * tan(30 * DEG)])
    behind = view(cam, [-5000.0, 0.0, z])
    far = view(cam, [20000.0, 0.0, 20000.0 * tan(15 * DEG)])
    assert cam.is_visible(*inside)
    assert not cam.is_visible(*outside_az)
    assert not cam.is_visible(*outside_el)
    assert not cam.is_visible(*behind)
    assert not cam.is_visible(*far)


def test_lever_arm_shifts_the_camera_position():
    r = geodetic_to_ecef(LAT, LON, H)
    C = dcm_ned_to_ecef(LAT, LON)
    lm = r + C @ [5000.0, 0.0, 1000.0]
    _, r0 = make_camera(lever=(0, 0, 0)).landmark_in_camera(r, C, lm)
    _, r1 = make_camera(lever=(1.0, 0, 0)).landmark_in_camera(r, C, lm)
    assert 0.9 < (r0 - r1) < 1.0        # camera 1 m further forward: ~1 m closer to a landmark ahead


def test_batched_shapes():
    cam = make_camera()
    C = np.repeat(dcm_ned_to_ecef(LAT, LON)[None], 4, axis=0)
    r = np.repeat(geodetic_to_ecef(LAT, LON, H)[None], 4, axis=0)
    d_c, rng = cam.landmark_in_camera(r, C, r[0] + C[0] @ [3000.0, 0, 1000.0])
    assert d_c.shape == (4, 3) and rng.shape == (4,)
    assert cam.is_visible(d_c, rng).shape == (4,)
