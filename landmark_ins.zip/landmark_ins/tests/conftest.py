"""Shared fixtures. The full default truth trajectory takes ~10 s, so build it once."""
import copy

import pytest

from nav.config import load_config
from nav.trajectory import generate_truth


@pytest.fixture(scope="session")
def default_cfg():
    return load_config()


@pytest.fixture(scope="session")
def default_truth(default_cfg):
    return generate_truth(default_cfg)


@pytest.fixture()
def short_cfg(default_cfg):
    """Same scenario but only the first 150 s of flight (fast tests)."""
    cfg = copy.deepcopy(default_cfg)
    cfg["simulation"]["max_duration_s"] = 150.0
    return cfg
