import numpy as np

from analysis.report import true_runs
from nav.constants import DEG
from nav.frames import dcm_ecef_to_ned, geodetic_to_ecef
from sim.suggest_landmarks import landmark_positions


def test_true_runs():
    assert true_runs([0, 1, 1, 0, 1, 0, 0, 1]) == [(1, 2), (4, 4), (7, 7)]
    assert true_runs([1, 1, 1]) == [(0, 2)]
    assert true_runs([0, 0]) == []


def test_suggested_landmark_is_at_the_requested_offset_to_the_right(default_truth):
    t = default_truth
    for item, offset in (("14", 0.0), ("14:250", 250.0), ("50:-300", -300.0), ("136:350", 350.0)):
        (lat, lon, _), = landmark_positions(t, [item], alt_m=1000.0)
        lm = geodetic_to_ecef(lat * DEG, lon * DEG, 2500.0)       # same height as the route
        k = int(np.argmin(np.linalg.norm(t.r_e - lm, axis=1)))
        # express the landmark in the aircraft's heading frame: x ahead, y to the right
        yaw = t.euler[k, 2]
        d_n = dcm_ecef_to_ned(*t.lla[k][:2]) @ (lm - t.r_e[k])
        along = d_n[0] * np.cos(yaw) + d_n[1] * np.sin(yaw)
        right = -d_n[0] * np.sin(yaw) + d_n[1] * np.cos(yaw)
        assert abs(along) < 1.0
        assert abs(right - offset) < 2.0


def test_suggested_landmark_outside_the_route_is_reported(default_truth):
    (lat, lon, text), = landmark_positions(default_truth, ["999"])
    assert lat is None and "outside the route" in text
