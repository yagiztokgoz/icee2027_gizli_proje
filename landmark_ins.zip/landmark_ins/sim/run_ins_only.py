"""Milestone 1: fly the route with an INS only and let the error accumulate.

Usage (from the project root):
    python -m sim.run_ins_only [path/to/scenario.yaml]

Writes to results/: summary.txt, ground_track.png, error_overview.png,
error_components_<case>.png, errors_1hz.npz
"""
import sys
from pathlib import Path

import numpy as np

from analysis.plots import plot_error_components, plot_error_overview, plot_ground_track
from analysis.report import build_report, landmark_geometry
from nav.config import load_config
from sim.pipeline import run_scenario

RESULTS = Path(__file__).resolve().parent.parent / "results"


def main(config_path=None):
    cfg = load_config(config_path)
    RESULTS.mkdir(exist_ok=True)
    res = run_scenario(cfg, verbose=True, verify=True)

    report = build_report(res)
    print("\n" + report)
    (RESULTS / "summary.txt").write_text(report + "\n", encoding="utf-8")

    truth = res.truth
    geos = landmark_geometry(res)
    times = {g["id"]: truth.t[g["k_closest"]] for g in geos}
    plot_ground_track(truth, res.cases, cfg["landmarks"], RESULTS / "ground_track.png")
    plot_error_overview(truth, res.cases, times, RESULTS / "error_overview.png")
    for key, case in res.cases.items():
        plot_error_components(truth, case, RESULTS / f"error_components_{key}.png")

    stride = int(round(cfg["simulation"]["imu_rate_hz"]))      # save at 1 Hz
    arrays = {"t_s": truth.t[::stride]}
    for key, case in res.cases.items():
        for name in ("horizontal_m", "height_m", "position_ned_m", "velocity_ned_mps",
                     "attitude_ned_rad"):
            arrays[f"{key}__{name}"] = case.errors[name][::stride]
    np.savez_compressed(RESULTS / "errors_1hz.npz", **arrays)
    print(f"\nResults written to {RESULTS}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else None)
