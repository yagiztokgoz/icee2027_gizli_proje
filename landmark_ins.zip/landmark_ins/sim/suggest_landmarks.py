"""Print landmark entries located relative to the flown route.

Usage (from the project root):
    python -m sim.suggest_landmarks 14:250 50:-300 64 [--alt 1000] [--config path.yaml]

Each argument is  DISTANCE_KM[:OFFSET_M]:
    DISTANCE_KM  distance along the flown route
    OFFSET_M     cross-track offset, positive = to the right of the flight direction
                 (default 0 = directly on the route)
The output lines can be pasted into the `landmarks:` list of config/scenario.yaml.
"""
import argparse
import math

import numpy as np

from nav.config import load_config
from nav.constants import DEG
from nav.frames import curvature_radii
from nav.trajectory import generate_truth


def landmark_positions(truth, items, alt_m=1000.0):
    """Landmark (lat_deg, lon_deg, description) for each 'DISTANCE_KM[:OFFSET_M]' item.

    Items outside the route give (None, None, message).
    """
    s = np.concatenate(([0.0], np.cumsum(np.linalg.norm(np.diff(truth.r_e, axis=0), axis=1))))
    out = []
    for item in items:
        dist_str, _, off_str = item.partition(":")
        d_m, offset = float(dist_str) * 1000.0, float(off_str) if off_str else 0.0
        if not 0.0 <= d_m <= s[-1]:
            out.append((None, None, f"skipped '{item}': outside the route (0..{s[-1] / 1000:.1f} km)"))
            continue
        lat = float(np.interp(d_m, s, truth.lla[:, 0]))
        lon = float(np.interp(d_m, s, truth.lla[:, 1]))
        course = float(truth.euler[int(np.argmin(np.abs(s - d_m))), 2])
        M, N = curvature_radii(np.array([lat]))
        lat += (-offset * math.sin(course)) / (M[0] + alt_m)                      # right of track, north part
        lon += (offset * math.cos(course)) / ((N[0] + alt_m) * math.cos(lat))     # right of track, east part
        out.append((lat / DEG, lon / DEG,
                    f"{d_m / 1000:.0f} km along the route, {offset:+.0f} m cross-track"))
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("points", nargs="+", help="DISTANCE_KM[:OFFSET_M]")
    ap.add_argument("--alt", type=float, default=1000.0, help="landmark ellipsoidal height [m]")
    ap.add_argument("--config", default=None, help="scenario file (default: config/scenario.yaml)")
    args = ap.parse_args()

    truth = generate_truth(load_config(args.config))
    length_km = np.sum(np.linalg.norm(np.diff(truth.r_e, axis=0), axis=1)) / 1000.0
    print(f"# route length {length_km:.1f} km")
    for i, (lat, lon, text) in enumerate(landmark_positions(truth, args.points, args.alt), start=1):
        if lat is None:
            print(f"# {text}")
            continue
        print(f"  - {{id: LM{i}, lat_deg: {lat:.5f}, lon_deg: {lon:.5f}, alt_m: {args.alt:.1f}, "
              f"sigma_ned_m: [2.0, 2.0, 3.0], note: \"{text}\"}}")


if __name__ == "__main__":
    main()
