"""Scenario pipeline: truth -> IMU -> INS (unaided and baro-damped) -> errors."""
import time
from dataclasses import dataclass, field

import numpy as np

from analysis.errors import navigation_errors
from nav.baro import BaroModel
from nav.camera import CameraModel
from nav.frames import ecef_to_geodetic_array
from nav.imu import ImuErrorModel, ideal_imu
from nav.ins import BaroAiding, BaroVerticalDamping, perturb_initial_state, run_ins
from nav.trajectory import generate_truth


@dataclass
class CaseResult:
    name: str
    r: np.ndarray
    v: np.ndarray
    C: np.ndarray
    lla: np.ndarray
    errors: dict


@dataclass
class ScenarioResult:
    cfg: dict
    seed: int
    truth: object
    camera: CameraModel
    cases: dict = field(default_factory=dict)
    ideal_check_max_error_m: float = float("nan")
    baro: object = None


def _case(name, truth, r, v, C):
    return CaseResult(name=name, r=r, v=v, C=C, lla=ecef_to_geodetic_array(r),
                      errors=navigation_errors(truth, r, v, C))


def run_scenario(cfg, seed=None, verbose=True, verify=True):
    """Run one realization.

    Random-number order (fixed, so results do not change when options toggle):
    IMU errors -> initial state errors -> baro errors.
    """
    log = print if verbose else (lambda *a, **k: None)
    seed = cfg["simulation"]["seed"] if seed is None else seed
    rng = np.random.default_rng(seed)

    t0 = time.time()
    truth = generate_truth(cfg)
    dist_km = np.sum(np.linalg.norm(np.diff(truth.r_e, axis=0), axis=1)) / 1000.0
    log(f"Truth: {truth.t[-1]:.0f} s, {dist_km:.1f} km, {len(truth)} samples "
        f"({time.time() - t0:.1f} s)")
    if not truth.completed:
        log("WARNING: route not completed within simulation.max_duration_s")

    dtheta_i, dv_i = ideal_imu(truth)
    res = ScenarioResult(cfg=cfg, seed=seed, truth=truth, camera=CameraModel(cfg["camera"]))

    if verify:
        r, _, _ = run_ins(truth.r_e[0], truth.v_e[0], truth.C_be[0], dtheta_i, dv_i, truth.dt)
        res.ideal_check_max_error_m = float(np.max(np.linalg.norm(r - truth.r_e, axis=1)))
        log(f"Check: error-free IMU -> max position error {res.ideal_check_max_error_m:.2e} m")

    imu = ImuErrorModel(cfg["imu"], truth.dt, rng)
    dtheta, dv = imu.corrupt(dtheta_i, dv_i)
    r0, v0, C0, _ = perturb_initial_state(truth, cfg["initial_errors"], rng)

    t0 = time.time()
    r, v, C = run_ins(r0, v0, C0, dtheta, dv, truth.dt)
    res.cases["unaided"] = _case("INS only (no aiding)", truth, r, v, C)
    log(f"INS only: done ({time.time() - t0:.1f} s)")

    if cfg["baro"]["enabled"]:
        t0 = time.time()
        bm = BaroModel(cfg["baro"], cfg["simulation"]["imu_rate_hz"], rng)
        res.baro = bm.measure(truth.lla[:, 2])
        damping = BaroVerticalDamping(cfg["baro"]["vertical_damping_time_constant_s"],
                                      bm.sample_interval_s)
        aiding = BaroAiding(res.baro.indices, res.baro.heights, damping)
        r, v, C = run_ins(r0, v0, C0, dtheta, dv, truth.dt, baro=aiding)
        res.cases["baro_damped"] = _case("INS + baro (vertical damping)", truth, r, v, C)
        log(f"INS + baro: done ({time.time() - t0:.1f} s)")
    return res
