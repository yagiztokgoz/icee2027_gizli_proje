# Landmark-aided INS for a GNSS-denied aircraft — simulation

Scenario (narrative only, it adds no constraint to the model): an exploration /
field-observation aircraft flies a planned route with no GNSS. Its INS error grows
along the route. The route passes known points (landmarks); one of them, X, is a
rescue area. A fixed camera sees each landmark and measures its azimuth/elevation, which
a later phase uses to correct the INS.

**Status: milestone 1 complete.** An aircraft flies the route in ECEF with a tactical-grade IMU and a strapdown INS,
and the INS error accumulates, with and without baro vertical damping. The camera
geometry is in place and checked (every landmark is visible), but no camera
measurements or filter yet (next phases: camera measurement model, error-state EKF, Monte Carlo).

## Quick start

    pip install -r requirements.txt
    python -m pytest -q              # 60 tests, ~40 s
    python -m sim.run_ins_only       # full run, ~1 min: report + figures in results/

All inputs are in `config/scenario.yaml` (validated on load, with precise error messages).
Place landmarks exactly relative to the flown route with

    python -m sim.suggest_landmarks 14:250 50:-300 64     # km along route [: metres cross-track, + = right]

## What the run produces (`results/`)

| File | Content |
|------|---------|
| `summary.txt` | error table, landmark visibility table, INS error at each landmark's first sighting |
| `ground_track.png` | true route, INS-computed tracks, landmarks, X |
| `error_overview.png` | horizontal error, height error (log + zoom), landmark pass times |
| `error_components_*.png` | N/E/height, velocity and attitude errors per case |
| `errors_1hz.npz` | the same errors at 1 Hz for your own plots |

## What "horizontal" and "vertical" error mean

* **Horizontal error** = `sqrt(dNorth^2 + dEast^2)`: how far apart the INS position and the
  true position are along the ground.
* **Height error** = INS ellipsoidal height - true height (positive: INS thinks it is higher).

They are *not* ECEF x/y/z components. Details: `docs/CONVENTIONS.md` section 3.

## Reading the baseline result

* Horizontal error is dominated by gyro bias and heading error and grows to tens of km
  (rule of thumb: 1 deg/h of gyro bias = 111 km/h of drift).
* Unaided, the height error diverges (100 km after 54 min) because the vertical channel
  of an inertial system is unstable. A barometer is therefore on by default; with the
  classical damping loop the height error stays within a few tens of metres.

## Layout

    config/scenario.yaml     all user inputs
    docs/CONVENTIONS.md      frames, rotations, error definitions, models, assumptions
    nav/                     constants, frames, earth, trajectory, imu, ins, baro, camera, noise, config
    analysis/                errors (metrics), report (tables), plots
    sim/                     pipeline, run_ins_only (entry point), suggest_landmarks
    tests/                   60 tests; physics tests are independent of the code under test

## Verification (all in `tests/`)

* Mechanization vs closed-form physics: stationary hold, Schuler oscillation amplitude and
  period, accelerometer-bias offset `2b/w_s^2`, gyro-drift `R eps (t - sin(w_s t)/w_s)`,
  vertical-channel `cosh(t/570 s)`, eastbound flight against the textbook specific force.
* Re-introducing each bug found during review (missing half-step Earth rotation, Coriolis
  sign, Earth-rate sign, gravity gradient, tangent-plane height error) makes a test fail.
* IMU units and statistics (ARW, VRW, bias, Gauss-Markov), truth model (speed, bank, orientation),
  camera geometry, config validation, determinism, report logic.

## Assumptions and limits

* The true path does not react to navigation error (route flown exactly).
* Kinematic truth (no aerodynamics, no wind). Heights are WGS84 ellipsoidal.
* Landmark heights, camera mounting, FOV, range and the 7 landmark positions are working
  defaults, not data about a real site. Replace them in the yaml.
* The camera is geometry only; noise, boresight error and trigger logic belong to the next phase.
