# Conventions

All code, identifiers and comments are in English. Internal units are SI
(m, s, rad). Human-friendly units (deg, deg/h, mg, ppm, ...) appear only in
`config/scenario.yaml` and are converted on load.

## 1. Frames

| Symbol | Frame | Definition |
|--------|-------|------------|
| `e` | ECEF | WGS84 Earth-centered Earth-fixed. Navigation (mechanization) frame. x: equator/prime meridian, z: north pole. |
| `n` | Local NED | North-East-Down at a geodetic position. Used for initial errors, error reporting, Euler angles. |
| `b` | Body | x forward, y right, z down (FRD). |
| `c` | Camera | x right, y down (image), z along the optical axis. |

ECEF axes are **not** "horizontal" and "vertical": at 39 N the ECEF z axis is
neither horizontal nor vertical. Human-readable quantities are always given in NED / height.

## 2. Rotation matrices

`C_xy` rotates a vector **from frame x to frame y**: `v_y = C_xy @ v_x`.

| Name | Meaning |
|------|---------|
| `C_be` | body -> ECEF (the attitude state of the INS and of the truth) |
| `C_ne`, `C_en` | NED -> ECEF, ECEF -> NED |
| `C_bn` | body -> NED (built from Euler angles) |
| `C_bc` | body -> camera |

Euler angles: ZYX sequence, `C_bn = Rz(yaw) Ry(pitch) Rx(roll)`.
Pitch positive = nose up. Roll positive = right wing down. Yaw = heading from north, clockwise.

## 3. Navigation errors (what "horizontal" and "vertical" mean)

All errors are *estimated minus true*.

| Quantity | Definition |
|----------|------------|
| North / East error | `dN = (lat_hat - lat) (M + h)`, `dE = (lon_hat - lon) (N + h) cos(lat)`; M, N = WGS84 meridian / prime-vertical radii. Curvilinear: it follows the Earth's surface, so it stays correct for errors of tens of km. |
| **Horizontal error** | `sqrt(dN^2 + dE^2)`: ground distance between where the INS thinks it is and where it is. |
| **Height error** | `h_hat - h` (WGS84 ellipsoidal heights). Positive = the INS believes it is higher than it is. The NED "Down" error is `-height error`. |
| Velocity error | ECEF velocity error rotated into NED at the true position. |
| Attitude error | rotation vector `eps` with `C_hat = exp([eps x]) C_true`, expressed in ECEF, reported in NED: components are tilt about N, tilt about E, heading error (about D). |

Why curvilinear and not "NED vector from the true point to the estimated point":
that chord dips below the local tangent plane by `d^2 / 2R`, i.e. a 72 km horizontal
error would show up as a fake ~400 m "vertical" error. (`tests/test_errors.py` guards this.)

## 4. Attitude error injected at start

`initial_errors.attitude_ned_deg = [a, b, c]` are 1-sigma rotation angles about the
North, East and Down axes (level tilts and heading error), the usual way alignment
error is specified. They are *not* roll/pitch/yaw of the aircraft.

## 5. Strapdown mechanization (ECEF)

IMU outputs are body-frame increments over one step `dt`, sensed with respect to
inertial space: `dtheta` (rad) and `dv` (m/s). With `E_half = exp(-[w_ie x] dt/2)`,
`E_full = E_half @ E_half`:

    C_new = E_full @ C @ exp([dtheta x])
    C_mid = E_half @ C @ exp([dtheta/2 x])           # mean attitude over the step
    r_mid = r + v dt/2
    v_new = v + C_mid @ dv + (g(r_mid) - 2 w_ie x v) dt
    r_new = r + (v + v_new) dt/2

`g` is plumb-bob gravity (J2 gravitation + centrifugal). The `E_half` factor in
`C_mid` matters: leaving it out makes a stationary vehicle with a perfect IMU drift
about 5 m in 50 min.

The simulated "ideal IMU" (`nav.imu.ideal_imu`) is the exact algebraic inverse of this
step, so an error-free INS reproduces the truth to ~1e-5 m. That only proves
self-consistency; the physics is verified separately in `tests/test_ins_physics.py`
against closed-form results (Schuler oscillation, accelerometer-bias offset,
gyro-drift growth, vertical-channel time constant, eastbound textbook specific force).

## 6. Truth trajectory

Kinematic coordinated-turn model: constant speed, yaw = course, pitch = flight path
angle, roll = bank angle (no wind, no sideslip, no angle of attack). Heading is steered
to the active waypoint; height is held with a rate-limited flight path angle.

**Assumption:** the true path does not depend on the navigation error. The route is
flown exactly while the INS error accumulates in the background. (In a real aircraft
that steers on its own navigation solution, a large error would also move the true
path; this simulation deliberately separates the two.)

## 7. IMU error model

`measured = M @ ideal + bias + noise` for each sensor.
* `M = I + diag(scale factor) + off-diagonal misalignment`, drawn once per run.
* `bias = turn-on bias (constant per run, sigma = bias_sigma) + Gauss-Markov bias
  instability (stationary sigma = bias_instability, correlation time bias_corr_time)`.
  The yaml "bias instability" is used as the Gauss-Markov stationary sigma (a modeling
  choice; it is not an Allan-variance floor).
* `noise`: white; increment std = `ARW * sqrt(dt)` (gyro), `VRW * sqrt(dt)` (accel).

Rule of thumb for checking results: a constant gyro bias of 1 deg/h makes the horizontal
position error grow at about `R * eps = 31 m/s` (111 km/h) once Schuler oscillations
average out; a constant accelerometer bias of 1 mg gives a bounded offset of `b R / g = 6.4 km`
(peak 12.8 km).

## 8. Barometer and vertical channel

The undamped INS vertical channel is unstable: height error grows like
`cosh(t / 570 s)`. Every real INS fixes this with a baro. Two things are provided:

* `baro` measurement model: true ellipsoidal height + Gauss-Markov bias + white noise.
* `INS + baro (vertical damping)`: classical third-order baro-inertial loop (triple pole
  at `-1/tau`, `tau = baro.vertical_damping_time_constant_s`). It follows the baro, so a baro
  bias becomes a height error of the same size. This is a **baseline**; the error-state
  filter of a later phase will treat the baro as a normal measurement.

## 9. Camera

Fixed, body-mounted pinhole camera. `mounting_rpy_deg = [roll, pitch, yaw]` of the
boresight relative to the body; pitch -15 means the boresight points 15 deg below the nose.
Landmark visibility: in front of the camera, `|x/z| <= tan(FOV_h/2)`, `|y/z| <= tan(FOV_v/2)`,
range <= `max_range_m`. Measurement angles: `az = atan2(x, z)` (positive right),
`el = atan2(-y, hypot(x, z))` (positive up).

## 10. Random numbers

One `numpy` generator per run, seeded with `simulation.seed`. Draw order is fixed:
IMU errors, then initial state errors, then baro errors. Switching the baro on or off
therefore does not change the IMU errors or the initial errors.

## 11. Scenario narrative

`scenario.description` and landmark `note` fields are free text. They have no effect
on any computation (X, the rescue area, is treated like every other landmark).
